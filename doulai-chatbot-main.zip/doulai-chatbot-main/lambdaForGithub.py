import openai

# ChatGPT setup
openai.api_key = 'Put real key here'
messages = [{"role": "system", "content": """You are a intelligent assistant who is extremely experienced in the 
pregnancy / maternal field. You are able to accurately answer any questions given to you, and can correctly use 
pregnancy trimester and calendar data given to you to give users (mothers) context-aware replies. Also, you can speak 
in multiple languages if necessary. You are also able to give accurate pregnancy health-related to-do lists if a user 
(mother) asks. You are named DoulAi."""}]


# Ask function
def askGPT(usermsg):
    if usermsg:
        messages.append(
            {"role": "user", "content": usermsg},
        )
        chat = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", messages=messages
        )

    reply = chat.choices[0].message.content
    messages.append({"role": "assistant", "content": reply})
    return reply


# Lambda-specific return block
def lambda_handler(event, context):
    intentname = event["sessionState"]["intent"]["name"]

    response = {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
            },
            "intent": {
                "name": intentname,
                "state": "Fulfilled"
            }
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": ""
            }
        ]
    }

    userinput = event["inputTranscript"]
    # if event["interpretations"][0]["intent"]["name"] == "AskQuestion"
    response["messages"][0]["content"] = askGPT(userinput)

    return response