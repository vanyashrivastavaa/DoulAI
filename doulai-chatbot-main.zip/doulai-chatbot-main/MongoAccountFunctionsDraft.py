from pymongo import MongoClient
import random
import string
from crypto_utils import CryptoUtils

client = MongoClient("replace")
db = client["replace"]
user_collection = db["users"]
token_collection = db["tokens"]

async def make_token_for(user_id):
    token_collection.delete_many({"user_id": user_id})
    generated_token = CryptoUtils.generate_random_token()
    new_token = {"user_id": user_id, "token": generated_token}
    token_collection.insert_one(new_token)
    return {"success": True, "token": new_token}

async def find_token(token):
    return token_collection.find_one({"token": token})

async def delete_token_for(user_id):
    try:
        token_collection.delete_one({"user_id": user_id})
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}

async def create_user(user):
    if not all(field in user for field in ["password", "email", "username"]):
        return {"success": False, "error": "Missing required fields"}

    if len(user["password"]) < 6:
        return {"success": False, "error": "Password must be more than 6 characters"}

    checking_for_user = user_collection.find_one(
        {"$or": [{"username": user["username"]}, {"email": user["email"]}]})

    if checking_for_user:
        return {"success": False, "error": "User already exists"}

    salt = "".join(random.choices(string.ascii_letters + string.digits, k=16))
    user_id = CryptoUtils.generate_random_id()
    encrypted_password = await CryptoUtils.encrypt_password(user["password"], CryptoUtils.convert_hex_to_buffer(salt))

    user.update({"user_id": user_id, "key": encrypted_password["key"], "salt": salt})
    new_user = user_collection.insert_one(user)
    return {"success": True, "user": new_user}

async def update_todos(user_id, todos):
    updated = user_collection.find_one_and_update({"user_id": user_id},
                                                  {"$set": {"todos": todos}},
                                                  return_document=True)
    if not updated:
        return {"success": False, "error": "Couldn't add new todo"}
    return {"success": True, "todos": todos, "user": updated}

async def check_for_user(username_or_email, _id):
    user = user_collection.find_one({"$or": [{"username": username_or_email},
                                              {"email": username_or_email},
                                              {"_id": _id}]})
    return user

async def login_user(username_or_email, password):
    user = user_collection.find_one({"$or": [{"username": username_or_email},
                                             {"email": username_or_email}]})

    if not user:
        return {"success": False, "error": "User with that username or email doesn't exist"}

    encrypted_password = await CryptoUtils.encrypt_password(password, CryptoUtils.convert_hex_to_buffer(user.get("salt", "")))
    key_string = CryptoUtils.convert_hex_to_buffer(user.get("key", ""))

    if encrypted_password["key"] == key_string:
        return {"success": True, "user": user}
    return {"success": False, "error": "Incorrect password"}

async def update_user(user_id, current_day=None, verified=None):
    updated = user_collection.find_one_and_update({"user_id": user_id},
                                                  {"$set": {"currentDay": current_day, "verified": verified}},
                                                  return_document=True)
    return updated

async def update_demographics({
    user_id, age, country, region, incomeBracket,
    raceEthnicity, personalRaceDefinition, education,
    personalEducationDefinition, pregnancyStatus
}):
    found = user_collection.find_one({"user_id": user_id})
    updated = user_collection.find_one_and_update({"user_id": user_id},
                                                  {"$set": {
                                                      "age": age,
                                                      "country": country,
                                                      "region": region,
                                                      "incomeBracket": incomeBracket,
                                                      "raceEthnicity": raceEthnicity,
                                                      "personalRaceDefinition": personalRaceDefinition,
                                                      "education": education,
                                                      "personalEducationDefinition": personalEducationDefinition,
                                                      "pregnancyStatus": pregnancyStatus
                                                  }},
                                                  return_document=True)
    return updated
