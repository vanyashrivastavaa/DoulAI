import hashlib
import secrets

class CryptoUtils:
    KEY_SIZE_BYTES = 64
    SALT_SIZE_BYTES = 16

    @staticmethod
    def convert_buffer_to_hex(buffer):
        return buffer.hex()

    @staticmethod
    def convert_hex_to_buffer(hex_string):
        return bytes.fromhex(hex_string)

    @staticmethod
    def derive_key_from_password(password_string, salt_buffer=None):
        text_encoder = hashlib.pbkdf2_hmac(
            'sha256', 
            password_string.encode('utf-8'), 
            salt_buffer or secrets.token_bytes(CryptoUtils.SALT_SIZE_BYTES),
            100000,
            dklen=CryptoUtils.KEY_SIZE_BYTES
        )
        
        key_string = CryptoUtils.convert_buffer_to_hex(text_encoder)
        salt_string = CryptoUtils.convert_buffer_to_hex(salt_buffer)
        return key_string, salt_string

    @staticmethod
    def encrypt_password(password, salt=None):
        key_string, salt_string = CryptoUtils.derive_key_from_password(password, salt)
        data = {
            'key': key_string,
            'salt': salt_string
        }
        return data
