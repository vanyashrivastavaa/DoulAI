import openai


# Class setup
class gpt:
    
    # ChatGPT setup
    openai.api_key = 'Put real key here'
    messages = [{"role": "system", "content": """You are a intelligent assistant who is extremely experienced in the 
    pregnancy / maternal field. You are able to accurately answer any questions given to you, and can correctly use 
    pregnancy trimester and calendar data given to you to give users (mothers) context-aware replies. Also, 
    you can speak in multiple languages if necessary. You are also able to give accurate pregnancy health-related 
    to-do lists if a user (mother) asks. You are named DoulAi."""}]

    def question(self, query):
        if query:
            self.messages.append(
                {"role": "user", "content": query},
            )
            chat = openai.ChatCompletion.create(
                model="gpt-3.5-turbo", messages=self.messages
            )

        reply = chat.choices[0].message.content
        self.messages.append({"role": "assistant", "content": reply})
        return reply
