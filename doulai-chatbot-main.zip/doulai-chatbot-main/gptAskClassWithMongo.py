import openai
import json
import pymongo


# Class setup
class gpt:
    openai.api_key = 'Put real key here'

    def __init__(self, user_id):
        # Check if user has previous chat history
        chat_history = mongostuff.get_chat_history_from_mongodb(user_id)
        if chat_history:
            self.messages = chat_history
        else:
            # Default system message
            self.messages = [
                {
                    "role": "system",
                    "content": """You are an intelligent assistant who is extremely experienced in the 
                    pregnancy / maternal field. You are able to accurately answer any questions given to you, and can 
                    correctly use pregnancy trimester and calendar data given to you to give users (mothers) 
                    context-aware replies. Also, you can speak in multiple languages if necessary. 
                    You are also able to give accurate pregnancy health-related to-do lists if a user (mother) asks. 
                    You are named DoulAi."""
                }
            ]

    def question(self, query):
        if query:
            self.messages.append({"role": "user", "content": query})

            # ChatGPT call
            chat = openai.ChatCompletion.create(
                model="gpt-3.5-turbo", messages=self.messages
            )

            reply = chat.choices[0].message.content
            self.messages.append({"role": "assistant", "content": reply})
            return reply


# MongoDB Part
class mongostuff:
    MONGODB_URI = ""
    DB_NAME = ""
    COLLECTION_NAME = ""

    # Upload chat history to MongoDB
    def upload_to_mongodb(self, user_id, chat_history):
        client = pymongo.MongoClient(self.MONGODB_URI)
        db = client[self.DB_NAME]
        collection = db[self.COLLECTION_NAME]
        collection.update_one({"user_id": user_id}, {"$set": {"chat_history": chat_history}}, upsert=True)
        client.close()

    # Retrieve chat history for user from MongoDB
    def get_chat_history_from_mongodb(self, user_id):
        client = pymongo.MongoClient(self.MONGODB_URI)
        db = client[self.DB_NAME]
        collection = db[self.COLLECTION_NAME]
        result = collection.find_one({"user_id": user_id}, {"_id": 0, "chat_history": 1})
        client.close()
        return result["chat_history"] if result else []

    def chat_with_history(self, user_id, query):
        # Create instance for user
        gpt_instance = gpt(user_id)

        # Previous chat history
        previous_chat_history = gpt_instance.messages

        # Combine
        combined_chat_history = []
        combined_chat_history = previous_chat_history.append({"role": "user", "content": query})

        # Get response
        response = gpt_instance.question(query)

        # Update chat history
        combined_chat_history += {"role": "assistant", "content": response}

        # Upload chat history to MongoDB
        self.upload_to_mongodb(user_id, combined_chat_history)

        # Update the GPT instance's message history just in case
        gpt_instance.messages = combined_chat_history

        # Return response
        return response
