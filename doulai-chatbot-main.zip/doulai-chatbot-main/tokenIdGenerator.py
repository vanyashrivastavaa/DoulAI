import random

class RandomGenerator:
    @staticmethod
    def generate_random_id():
        min_val = 100000000000  # Minimum 12-digit number
        max_val = 999999999999  # Maximum 12-digit number
        random_id = random.randint(min_val, max_val)
        return str(random_id)

    @staticmethod
    def generate_random_token(size=12):
        min_val = 100000000000  # Minimum 12-digit number
        max_val = 999999999999  # Maximum 12-digit number
        random_id = random.randint(min_val, max_val)
        return str(random_id)
