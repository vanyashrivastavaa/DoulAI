import random
import string
import logging
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from crypto_utils import CryptoUtils

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB connection
with MongoClient("replace") as client:
    db = client["replace"]
    user_collection = db["users"]
    token_collection = db["tokens"]

async def make_token_for(user_id):
    try:
        token_collection.delete_many({"user_id": user_id})
        generated_token = CryptoUtils.generate_random_token()
        new_token = {"user_id": user_id, "token": generated_token}
        token_collection.insert_one(new_token)
        logger.info("Token generated and saved for user_id: %s", user_id)
        return {"success": True, "token": new_token}
    except PyMongoError as e:
        logger.error("Failed to make token for user_id: %s. Error: %s", user_id, str(e))
        raise Exception("Failed to make token for user_id")

async def find_token(token):
    try:
        return token_collection.find_one({"token": token})
    except PyMongoError as e:
        logger.error("Failed to find token for token: %s. Error: %s", token, str(e))
        raise Exception("Failed to find token for token")

async def delete_token_for(user_id):
    try:
        token_collection.delete_one({"user_id": user_id})
        logger.info("Token deleted for user_id: %s", user_id)
        return {"success": True}
    except PyMongoError as e:
        logger.error("Failed to delete token for user_id: %s. Error: %s", user_id, str(e))
        raise Exception("Failed to delete token for user_id")

async def create_user(user):
    try:
        if not all(field in user for field in ["password", "email", "username"]):
            return {"success": False, "error": "Missing required fields"}

        salt = "".join(random.choices(string.ascii_letters + string.digits, k=16))
        user_id = CryptoUtils.generate_random_id()

        checking_for_user = user_collection.find_one(
            {"$or": [{"username": user["username"]}, {"email": user["email"]}]})

        if len(user["password"]) < 6:
            return {"success": False, "error": "Password must be more than 6 characters"}

        if checking_for_user:
            return {"success": False, "error": "User already exists"}

        encrypted_password = await CryptoUtils.encrypt_password(user["password"], CryptoUtils.convert_hex_to_buffer(salt))

        user.update({"user_id": user_id, "key": encrypted_password["key"], "salt": salt})
        new_user = user_collection.insert_one(user)
        logger.info("User created with user_id: %s", user_id)
        return {"success": True, "user": new_user}
    except PyMongoError as e:
        logger.error("Failed to create user. Error: %s", str(e))
        raise Exception("Failed to create user")

async def update_todos(user_id, todos):
    try:
        updated = user_collection.find_one_and_update({"user_id": user_id},
                                                      {"$set": {"todos": todos}},
                                                      return_document=True)
        if not updated:
            logger.warning("Couldn't update todos for user_id: %s", user_id)
            return {"success": False, "error": "Couldn't update todos"}
        logger.info("Todos updated for user_id: %s", user_id)
        return {"success": True, "todos": todos, "user": updated}
    except PyMongoError as e:
        logger.error("Failed to update todos for user_id: %s. Error: %s", user_id, str(e))
        raise Exception("Failed to update todos")

async def check_for_user(username_or_email, _id):
    try:
        user = user_collection.find_one({"$or": [{"username": username_or_email},
                                                  {"email": username_or_email},
                                                  {"_id": _id}]})
        return user
    except PyMongoError as e:
        logger.error("Failed to check for user. Error: %s", str(e))
        raise Exception("Failed to check for user")

async def login_user(username_or_email, password):
    try:
        user = user_collection.find_one({"$or": [{"username": username_or_email},
                                                 {"email": username_or_email}]})

        if not user:
            return {"success": False, "error": "User with that username or email doesn't exist"}

        salt = CryptoUtils.convert_hex_to_buffer(user.get("salt", ""))
        encrypted_password = await CryptoUtils.encrypt_password(password, salt)

        if encrypted_password["key"] == CryptoUtils.convert_hex_to_buffer(user.get("key", "")):
            return {"success": True, "user": user}
        return {"success": False, "error": "Incorrect password"}
    except PyMongoError as e:
        logger.error("Failed to login user. Error: %s", str(e))
        raise Exception("Failed to login user")

async def update_user(user_id, current_day=None, verified=None):
    try:
        updated = user_collection.find_one_and_update({"user_id": user_id},
                                                      {"$set": {"currentDay": current_day, "verified": verified}},
                                                      return_document=True)
        return updated
    except PyMongoError as e:
        logger.error("Failed to update user. Error: %s", str(e))
        raise Exception("Failed to update user")

async def update_demographics({
    user_id, age, country, region, incomeBracket,
    raceEthnicity, personalRaceDefinition, education,
    personalEducationDefinition, pregnancyStatus
}):
    try:
        found = user_collection.find_one({"user_id": user_id})
        updated = user_collection.find_one_and_update({"user_id": user_id},
                                                      {"$set": {
                                                          "age": age,
                                                          "country": country,
                                                          "region": region,
                                                          "incomeBracket": incomeBracket,
                                                          "raceEthnicity": raceEthnicity,
                                                          "personalRaceDefinition": personalRaceDefinition,
                                                          "education": education,
                                                          "personalEducationDefinition": personalEducationDefinition,
                                                          "pregnancyStatus": pregnancyStatus
                                                      }},
                                                      return_document=True)
        return updated
    except PyMongoError as e:
        logger.error("Failed to update demographics. Error: %s", str(e))
        raise Exception("Failed to update demographics")
