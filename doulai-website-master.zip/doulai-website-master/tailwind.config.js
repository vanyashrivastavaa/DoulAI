/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    listStyleType: {
      roman: 'upper-roman',
    },
    screens: {
      'sm': '640px',
      // => @media (min-width: 640px) { ... }

      'md': '768px',
      // => @media (min-width: 768px) { ... }

      'semimd' : '900px',

      'lg': '1024px',
      // => @media (min-width: 1024px) { ... }

      'xl': '1280px',
      // => @media (min-width: 1280px) { ... }

      '2xl': '1536px',
    },
    extend: {
      fontFamily: {
        "questrial": ['Questrial', 'sans-serif'],
        "rozhaOne": ['Rozha One', 'serif'],
        "antiqua": ['Antiqua', 'serif']
      },
      colors: {
        "primaryPink": "#f7b4d1",
        "secondaryPink": "#e592b4",
        "tertiaryPink": "#e6b7d0",
        "unsaturatedPink": "#f8edf3",
        "grayPink": "#f5d0e4",
        "lightPink": "#fffaf6",
        "primaryEarth": "#bcb5ab",
        "unsaturatedEarth": "#f5f2ef",
        "unsaturatedDarkEarth": "#f5f3f0",
        "lightEarth": "#faf9f0"
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic':
          'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
      },
    },
  },
  plugins: [],
}
