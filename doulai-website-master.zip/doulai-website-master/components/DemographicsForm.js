import React, { useState } from "react";
import {
  ages,
  countries,
  educationLevels,
  incomeBrackets,
  pregnancyStatuses,
  raceEthnicities,
  trimesters,
} from "@/utils/standards";
import ReactDatePicker from "react-datepicker";
import Spinner from "./Spinner";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faXmark } from "@fortawesome/free-solid-svg-icons";

export default function DemographicsForm({handleFormSubmit, user, setShowDemographics}) {

    const [loading, setLoading] = useState(false)
    const [isDisabled, setIsDisabled] = useState(false)

    //Demographics Data
    const [age, setAge] = useState(user.age ?? 0);
    const [country, setCountry] = useState(user.country ?? 0);
    const [region, setRegion] = useState(user.region ?? "");
    const [incomeBracket, setIncomeBracket] = useState(user.incomeBracket ?? 0);
    const [raceEthnicity, setRaceEthnicity] = useState(user.raceEthnicity ?? 0);
    const [personalRaceDefiniton, setPersonalRaceDefiniton] = useState(user.personalRaceDefiniton ??"")
    const [education, setEducation] = useState(user.education ?? 0)
    const [personalEducationDefinition, setPersonalEducationDefinition] = useState(user.personalEducationDefinition ?? "")
    const [pregnancyStatus, setPregnancyStatus] = useState(user.pregnancyStatus ?? 0)
    const [trimester, setTrimester] = useState(user.trimester ?? 0)
    const [daysIntoTrimester, setDaysIntoTrimester] = useState(user.daysIntoTrimester ?? 0)
    // const [deliveryDate, setDeliveryDate] = useState("")

    console.log("User Passed to Form: ", user)

    const handleSubmit = async (e) => {
      setLoading(true)
      setIsDisabled(true)
      e.preventDefault()
      await handleFormSubmit({age, country, region, incomeBracket, raceEthnicity, personalRaceDefiniton, education, personalEducationDefinition, pregnancyStatus, trimester, daysIntoTrimester})
      setLoading(false)
      setIsDisabled(false)
    }

    return (
      <>
      <div className="h-screen top-0 fixed w-screen overflow-y-scroll bg-black/50">
        <FontAwesomeIcon onClick={() => setShowDemographics(false)} className="w-5 fixed cursor-pointer text-rose-500 p-2 bg-lightEarth rounded-full top-4 right-4" icon={faXmark}></FontAwesomeIcon>
        <div
            className={`mt-32 md:mt-8 w-11/12 sm:w-1/2 lg:w-5/12 secondary bg-lightEarth mb-10 mx-auto px-10 py-6 text-center rounded font-playfair`}
          >
            <div className="secondary xl:text-2xl text-primaryPink mx-auto font-bold">
              Quick Questionnaire:
            </div>
            <form onSubmit={async (e) => await handleSubmit(e)} className="text-center secondary text-primaryPink w-full flex flex-col items-center overflow-y-auto">
            {/* !(hasProp) || !user format has the input display whenever no user is present or the property is missing */}
                <label htmlFor="" className="text-xl text-primaryPink ">
                  Age:
                </label>
                <select
                  className="ml-2 outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                  onChange={(e) => setAge(e.target.value)}
                  value={age}
                  name=""
                  id=""
                >
                  <option selected disabled></option>
                  {ages.map((age, i) => (
                    <option key={`age${i}`} value={i}>
                      {age}
                    </option>
                  ))}
                </select>
              
              <label htmlFor="" className="text-xl mt-4 text-primaryPink ">
                Country of Residence:
              </label>
              <select
                className="w-1/3 outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                onChange={(e) => setCountry(e.target.value)}
                value={country}
                name=""
                id=""
              >
                <option selected disabled></option>
                {countries.map((c, i) => (
                  <option key={`country${i}`} value={c.code}>
                    {c.name}
                  </option>
                ))}
              </select>

              <label htmlFor="" className="text-xl mt-4 text-primaryPink">
                Region/State:
              </label>
              <input
                required
                className="pb-0.5 ml-2 outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                onChange={(e) => setRegion(e.target.value.replace("  ", " "))}
                value={region}
                type="text"
                name=""
                placeholder="New York, Ontario..."
                id=""
              />

              <label htmlFor="" className="text-xl mt-4 text-primaryPink  ">
                Race/Ethnicity:
              </label>
              <select
                className="w-1/3 outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                onChange={(e) => setRaceEthnicity(e.target.value)}
                value={raceEthnicity}
                name=""
                id=""
              >
                {raceEthnicities.map((identifier, i) => (
                  <option key={`identity${i}`} value={i}>
                    {identifier}
                  </option>
                ))}
              </select>
              {
                raceEthnicity == 5 ? <>
                <label htmlFor="" className="text-xl mt-2 text-primaryPink  ">
                  Race/Ethnicity Definition:
                </label>
                <input
                minLength={2}
                  className="pb-0.5 ml-2 placeholder-primaryPink outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                  onChange={(e) => setPersonalRaceDefiniton(e.target.value.replace("  ", " "))}
                  value={personalRaceDefiniton}
                  type="text"
                  name=""
                  placeholder="How do you identify?"
                  id=""
                />
                </> : <></>
              }

              <label htmlFor="" className="text-xl mt-4 text-primaryPink  ">
                Income Bracket:
              </label>
              <select
                className="w-1/3 outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                onChange={(e) => setIncomeBracket(e.target.value)}
                value={incomeBracket}
                name=""
                id=""
              >
                {incomeBrackets.map((bracket, i) => (
                  <option key={`bracket${i}`} value={i}>
                    {bracket}
                  </option>
                ))}
              </select>

              <label htmlFor="" className="text-xl mt-4 text-primaryPink  ">
                Education:
              </label>
              <select
                className="w-1/3 outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                onChange={(e) => setEducation(e.target.value)}
                value={education}
                name=""
                id=""
              >
                {educationLevels.map((identifier, i) => (
                  <option key={`education${i}`} value={i}>
                    {identifier}
                  </option>
                ))}
              </select>
              {
                education == 7 ? <>
                <label htmlFor="" className="text-xl mt-2 text-primaryPink  ">
                  Education Definition:
                </label>
                <input
                  minLength={2}
                  className="pb-0.5 ml-2 outline-none placeholder-primaryPink text-lg bg-transparent border-b-2 border-primaryPink"
                  onChange={(e) => setPersonalEducationDefinition(e.target.value.replace("  ", " "))}
                  value={personalEducationDefinition}
                  type="text"
                  name=""
                  placeholder="Your level of education.."
                  id=""
                /></> : <></>
              }

              <label htmlFor="" className="text-xl mt-4 text-primaryPink ">
                Pregnancy Status:
              </label>
              <select
                className="w-1/3 outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                onChange={(e) => setPregnancyStatus(e.target.value)}
                value={pregnancyStatus}
                name=""
                id=""
              >
                {pregnancyStatuses.map((stat, i) => (
                  <option key={`stat${i}`} value={i}>
                    {stat}
                  </option>
                ))}
              </select>

              {
                pregnancyStatus == 0 ?
                <>
                <label htmlFor="" className="text-xl mt-4 text-primaryPink  ">
                  Trimester:
                </label>
              <select
                className="w-1/3 outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                onChange={(e) => setTrimester(e.target.value)}
                value={trimester}
                name=""
                id=""
              >
                {trimesters.map((stat, i) => (
                  <option key={`tri${i}`} value={i}>
                    {stat}
                  </option>
                ))}
              </select>
                <label htmlFor="" className="text-xl mt-4 text-primaryPink  ">
                  Days into Trimester:
                </label>
                <input
                  className="pb-0.5 ml-2 outline-none text-lg bg-transparent border-b-2 border-primaryPink"
                  onChange={(e) => setDaysIntoTrimester(e.target.value.replace("  ", " "))}
                  value={daysIntoTrimester}
                  type="number" min={0}
                  name=""
                  id=""
                />
                {/* <label htmlFor="" className="text-xl mt-4 text-primaryPink  ">
                  Delivery Date:
                </label>
                <ReactDatePicker></ReactDatePicker> */}
                </>
                 : <></>
              }

              <button disabled={isDisabled} type="submit" className={`px-4 py-2 text-white bg-primaryPink hover:bg-pink-400 transtion duration-300 ease-in-out rounded mt-2`}>
                    Submit
              </button>
              {/* <button onClick={handleSubmit} className={`px-4 py-2 text-white bg-primaryPink hover:bg-pink-400 transtion duration-300 ease-in-out rounded mt-2`}>
                    Submit
                </button> */}
            </form>
          </div>
      </div>
        </>
    )

}