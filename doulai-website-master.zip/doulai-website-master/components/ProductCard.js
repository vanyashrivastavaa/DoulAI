import Link from "next/link"
import Image from "next/image"

export default function ProductCard({user, title, image, link}) {
    return (
        <Link className={`${user ? "cursor-pointer" : "cursor-default"}`} href={user ? `${link}` : "/"}>
            <div className="flex mx-auto hover:-translate-y-4 group duration-300 ease-in-out transition flex-col text-primaryPink secondaryText font-semibold">
            <Image alt={title} className="shadow-xl/50 hover:shadow-2xl/90 transition duration-300 ease-in-out rounded w-[800px] bg-cover" width={500} height={500} src={`/products/${image}`}></Image>
              {title}
            </div>
          </Link>
    )
}