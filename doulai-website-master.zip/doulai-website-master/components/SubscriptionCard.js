import { faCheck } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Image from "next/image";

export default function SubscriptionCard({subscription, activeSubscription, split}) {
    return (
        <div className={`w-1/${split} hover:scale-105 transition duration-300 ease-in-out pb-20 bg-primaryPink text-start px-6 py-4 rounded`}>
            <p className="semi font-rozhaOne text-white">{subscription.title}</p>
            {subscription.index == activeSubscription ? <>
            <FontAwesomeIcon className="px-2 py-1 rounded-full text-primaryPink bg-white" icon={faCheck}></FontAwesomeIcon>
            </>: null}
            <ul className="flex w-3/4 mt-2 flex-col text-white questrial">
                {subscription.benefits.map((benefit, i) => (
                    <li key={`cardItem${i}`} className="small">{benefit}</li>
                ))}
            </ul>
        </div>
    )
}