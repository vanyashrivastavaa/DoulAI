import { faCheck, faPencil, faX, faXmark } from "@fortawesome/free-solid-svg-icons"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { useState } from "react"

export default function DisplayStat({title, updating, type, stat, personalTitle, personalDefinition, personalTrigger, edit, selection, options}) {
    
    const formatStat = (stat) => {
        if(!selection) {
            return stat 
         } else if (updating == "country") {
            let countryFound =  options.filter(c => c.code == stat)[0] 
            return countryFound ? countryFound.name : "No Country Found"
         } else { 
            return options[stat]
        }

    }
    
    const [isEditing, setIsEditing] = useState(false)
    const [pureValue, setPureValue] = useState(stat)
    const [statistic, setStatistic] = useState(formatStat(stat))
    const [definition, setDefinition] = useState(personalDefinition?.trim())
    
    
    console.log(`${title}: ${statistic}`)
    return (
        <div className="px-2 w-full">
        {
            isEditing ? 
        <>
            <form className="flex w-full text-center flex-col" onSubmit={e => {
                        setIsEditing(false)
                        let obj = {}
                        switch(type) {
                            case "number":
                                console.log("Its a number")
                                obj[updating] = Number.parseInt(pureValue)
                                break;
                            case "text": 
                                console.log("Its text")
                                obj[updating] = pureValue.trim()
                                break;
                            case "date":
                                console.log("Its a date")
                                obj[updating] = pureValue
                                break;
                            default:
                                console.log("Its default case")
                                obj[updating] = pureValue 
                                break;
                        }
                        if(personalTrigger) {
                            switch(updating) {
                                case "raceEthnicity":
                                    obj["personalRaceDefinition"] = definition
                                    break;
                                case "education":
                                    obj["personalEducationDefinition"] = definition
                                    break;
                            }
                        }
                        console.log("Updating: ", updating)
                        console.log(obj)
                        edit(obj)
                    }}>
                <div className="flex justify-center">
                <label className="text-grayPink secondary mr-2 font-normal">{title}</label>
                {
                    selection ? 
                    <>
                    <select
                      className={`outline-none text-primaryPink font-bold secondary bg-transparent border-b-2 border-primaryPink w-1/4`}
                      onChange={(e) => {
                        setPureValue(e.target.value)
                        setStatistic(formatStat(e.target.value))
                    }}
                      value={pureValue}
                    >
                      {updating != "country" ? 
                      <>
                      {options.map((option, i) => (
                        <option key={`option${i}`} className="text-primaryPink" value={i}>
                          {option}
                        </option>
                      ))}
                      </> : 
                      <>
                      {options.map((c, i) => (
                        <option key={`option${i}`} className="text-primaryPink" value={c.code}>
                          {c.name}
                        </option>
                      ))}
                      </>}
                    </select>
                    </> : 
                    <>
                        <input type={type} className="appearance-none outline-none secondary bg-transparent text-primaryPink font-bold border-b-2 border-primaryPink w-1/2" value={statistic} onChange={(e) => {
                        setPureValue(e.target.value)
                        setStatistic(formatStat(e.target.value))
                    }} />
                    </>
                }
                <button type="submit">
                    <FontAwesomeIcon className="w-4 h-auto text-green-200 hover:text-green-400 cursor-pointer px-2 py-1 bg-white rounded-full transition duration-300 ease-in-out my-auto ml-2" icon={faCheck}>
                    </FontAwesomeIcon>
                </button>
                </div>
                <div className="flex justify-center my-2 ml-0">
                {
                    selection && pureValue == personalTrigger ?
                        <input required minLength={2} placeholder="What's your defintion...?" onChange={(e)=>setDefinition(e.target.value.replace("  ", " "))} className="outline-none placeholder-primaryPink appearance-none placeholder:text-lightTeal bg-transparent border-primaryPink text-primaryPink border-b-2" type="text" value={definition} />
                     : 
                    <>
                    </>
                }

                </div>
            </form>
        </> : 
        <>
        <div className="flex flex-col w-min min-w-max mx-auto">
            <div className="secondary text-primaryPink flex font-bold">
                <span>
                <span className="text-grayPink mr-2 font-normal">{title}</span>{statistic}</span>
                <button onClick={() => setIsEditing(true)}>
                <FontAwesomeIcon className="w-4 h-auto text-grayPink cursor-pointer hover:text-primaryPink transition duration-300 ease-in-out my-auto ml-2" icon={faPencil}></FontAwesomeIcon>
                </button>
            </div>
                {  parseInt(pureValue) == parseInt(personalTrigger) ? 
                <span className="text-primaryPink secondary font-bold">{definition}</span> : <></> }
            
        
    </div>
    </>
        }
    </div>
    )
}