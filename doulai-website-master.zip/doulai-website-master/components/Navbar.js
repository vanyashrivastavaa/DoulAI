import Link from "next/link"
import { useEffect, useState } from "react"

export default function Navbar({user}) {
    const [hidden, setHidden] = useState(false)
    let offsetHeight
    let original
    let lastScrollTop
    let reset = 1
    let updatePos
    useEffect(()=>{
        const additional = -50
        original = document.getElementById("navbar").offsetHeight
        offsetHeight = original
        lastScrollTop = window.scrollY
        console.log("Offset Height: ", offsetHeight)
        window.addEventListener("scroll", () => {
            const windowYPos = window.pageYOffset || document.documentElement.scrollTop
            // console.log("curr: " ,windowYPos)
            // console.log("last: ", lastScrollTop)
            // console.log("\n\n")
            const scrollingUp = (lastScrollTop > windowYPos) //relative to the offsetheight
            if(Math.abs(lastScrollTop - windowYPos) > 0.5) {
                updatePos = true
                if(scrollingUp && reset == 0) {
                    console.log("Scrolling Up")
                    //Switches to scrolling up
                    reset = 1
                    offsetHeight = windowYPos
                    console.log("OffsetHeight: ", offsetHeight)
                } else if(!scrollingUp && reset == 1) {
                    console.log("Scrolling Down")
                    //Switches to scrolling down
                    reset = 0
                    offsetHeight = windowYPos
                    console.log("OffsetHeight: ", offsetHeight)
                }
            }
            // const nav = document.getElementById("navbar")
            // console.log("Window: ", window.scrollY)
            if((windowYPos >= offsetHeight + additional) && (windowYPos > original)) { //Y position is lower than this bar
                setHidden(true)
            } else {
                setHidden(false)
            }
            if(updatePos) lastScrollTop = windowYPos
        })
    }, [])
    return (
        <div id="navbar" className={`w-full top-0 sticky h-min ${hidden ? "opacity-0" : "opacity-100"} transition duration-300 ease-in-out flex px-10 py-8 bg-white justify-between text-primaryPink`}>
            <Link href={"/"} className={`${hidden ? "cursor-default" : "cursor-pointer"} text-6xl font-rozhaOne`}>
                DoulAI
            </Link>
            <div className={`flex gap-4 text-lg font-semibold text-primaryPink items-center`}>
                <Link className={`${hidden ? "cursor-default" : "cursor-pointer"} hover:text-unsaturatedPink transition duration-300 ease-in-out`} href={`/`}>Home</Link>

                <Link className={`${hidden ? "cursor-default" : "cursor-pointer"} hover:text-unsaturatedPink transition duration-300 ease-in-out`} href={`/about`}>About</Link> {/* <Link className="text-white hover:font-semibold transition duration-300 ease-in-out" href={`/about/`}>About</Link> */}
                {user ? 
                <>
                {
                    user.verified ?      
                    <> 
                    <Link className={`${hidden ? "cursor-default" : "cursor-pointer"} hover:text-unsaturatedPink transition duration-300 ease-in-out`} href={`/blogs`}>Blogs</Link>  
                    <Link className={`${hidden ? "cursor-default" : "cursor-pointer"} hover:text-unsaturatedPink transition duration-300 ease-in-out`} href={`/chat`}>Chat with Doula</Link>            
                    <Link className={`${hidden ? "cursor-default" : "cursor-pointer"} hover:text-unsaturatedPink transition duration-300 ease-in-out`} href={`/taskList`}>Task List</Link>              
                    <Link className={`${hidden ? "cursor-default" : "cursor-pointer"} hover:text-unsaturatedPink transition duration-300 ease-in-out`} href={`/profile`}>Profile</Link>
                    </> 
                        :                    
                        <></>
                }
                    <Link className={`${hidden ? "cursor-default" : "cursor-pointer"} hover:text-unsaturatedPink transition duration-300 ease-in-out`} href={"/api/logout"}>Logout</Link>                
                </> : 
                <>
                    <Link className={`${hidden ? "cursor-default" : "cursor-pointer"} hover:text-unsaturatedPink transition duration-300 ease-in-out`} href={"/auth/login"}>Login</Link>
                    <Link className={`${hidden ? "cursor-default" : "cursor-pointer"} hover:text-unsaturatedPink transition duration-300 ease-in-out`} href={"/auth/signup"}>Signup</Link>                
                </>}
            </div>
        </div>
    )
}