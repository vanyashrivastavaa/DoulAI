import { faWrench, faXmark } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Link from "next/link";

export default function ComingSoon({message}) {
  return (
    <div className="flex h-screen w-screen items-center">
      <Link href={"/"}>
        <FontAwesomeIcon
          className="w-8 h-8 hover:text-unsaturatedPink duration-300 transition ease-in-out fixed cursor-pointer text-primaryPink top-4 right-4"
          icon={faXmark}
        ></FontAwesomeIcon>
      </Link>
      <div className="flex flex-col space-y-2 w-min min-w-max mx-auto">
        <FontAwesomeIcon
          className={`w-12 animate-bounce h-12 mx-auto text-unsaturatedPink`}
          icon={faWrench}
        ></FontAwesomeIcon>
        <p className="semi text-primaryPink font-semibold text-center">
          {message}
        </p>
      </div>
    </div>
  );
}
