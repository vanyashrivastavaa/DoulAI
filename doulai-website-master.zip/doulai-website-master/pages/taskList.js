import { withIronSessionSsr } from "iron-session/next"
import { ironOptions } from "@/utils/ironConfig"
import { checkForUser, connectMongo } from "@/utils/api"
import Navbar from "@/components/Navbar"
import { useEffect, useState } from "react"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faCross, faListCheck, faPenNib, faTrash, faXmark } from "@fortawesome/free-solid-svg-icons"
import { useRouter } from "next/router"
import {
  ages,
  countries,
  days,
  educationLevels,
  incomeBrackets,
  pregnancyStatuses,
  raceEthnicities,
} from "@/utils/standards";
import DisplayStat from "@/components/DisplayStat"

export const getServerSideProps = withIronSessionSsr(async function ({
  req,
  res,
}) {
  await connectMongo();
  let user = null;
  // if(user) {
  //   delete user.key
  //   delete user.salt
  //   console.log("User: ", user)
  //   console.log("Key: " + user.keys)
  //   req.session.user = user
  //   await req.session.save()
  // }
  console.log("Session User in Profile View: ", req.session.user);
  console.log(`Undefined ${req.session.user === undefined}`)
  if(!req.session.user?.verified) {
    return {
      redirect: {
        destination: '/?reasonKicked=You can\'t access your profile until you verify your email',
        permanent: true,
      },
    }
  }
  if(!req.session.user || req.session.user === undefined || !req.session.user.verified) {
    return {
      redirect: {
        destination: '/',
        permanent: true,
      },
    }
  } 
  return { props: { user: req.session.user ?? null } };
},
ironOptions);

  export default function Profile({user}) {
    //Stop reloading when adding/deleting/editing todos and instead handle the payload on window.onbeforeunload (before route changes and etc..)
    console.log("User: ", user)
    const checklist = ["Drink 5 cups of water", "Exercise for 30 minutes", "Go for a walk", "Check in with obgyn"]

    const router = useRouter()
    const [isAddingTodo, setIsAddingTodo] = useState(false)
    const [todoValue, setTodoValue] = useState("")
    const [todos, setTodos] = useState(user.todos ?? [])
    const [todoLabel, setTodoLabel] = useState("Submit")
    const [disableAddTodo, setDisableAddTodo] = useState(false)

    const handleFormSubmit = async ({age = null, country = null, region = null, incomeBracket = null, raceEthnicity = null, personalRaceDefiniton = null, education = null, personalEducationDefinition = null, pregnancyStatus = null, email = null, username = null, password = null, trimester = null, daysIntoTrimester = null}) => {
      console.log({
        trimester,
        daysIntoTrimester,
        username,
        password,
        email,
        age,
        country,
        region: region ? region.trim() : "",
        incomeBracket,
        raceEthnicity,
        personalRaceDefiniton: personalRaceDefiniton ? personalRaceDefiniton.trim() : "",
        education,
        personalEducationDefinition: personalEducationDefinition ? personalEducationDefinition.trim() : "",
        pregnancyStatus,
        trimester,
        daysIntoTrimester
      })
      let data = await fetch("/api/demographics/update", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        
        body: JSON.stringify({
          trimester,
          daysIntoTrimester,
          username,
          password,
          email,
          age,
          country,
          region,
          incomeBracket,
          raceEthnicity,
          personalRaceDefiniton,
          education,
          personalEducationDefinition,
          pregnancyStatus
        })
      }).then(res => res.json())
      if(data.success) {
        alert("Successfully updated demographics")
        return
      } else {
        alert("Failed to update demographics")
      }
      return false
    }

    const markFinished = async (val, finished) => {
      console.log(`Todo: ${val.item}, finished: ${finished}`)
      console.log(todos[0] == val)
      let list = todos.map((todo) => (todo == val) ? {item: todo.item, finished} : todo)
      console.log("Updated list: ", list)
      let data = await updateTodos(user.user_id, list)
      setTodos(list)
      console.log(data)
    }

    const deleteTodo = async (val) => {
      let user_id = user.user_id
      let list = []
      let stillRemoving = true
      for(let i = 0; i < todos.length; i++) {
        if(todos[i] == val && stillRemoving) {
          stillRemoving = false
          continue
        }
        list.push(todos[i])
      }
      let data = await updateTodos(user_id, list)
      console.log("Data: ", data)
      if(data.success) {
          // alert("Deleted todo!")
          // router.reload()
          setTodos(list)
          // return
      } else {
          alert("Error: " + data.error)
      }
      setTodoValue("")
      setIsAddingTodo(false)
    }

    const updateTodos = async (user_id, todos) => {
      console.log("Updating value")
      console.log("Todos: ", todos)
      console.log(JSON.stringify(todos))
      let data = await fetch("/api/todos/update", {
          method: "POST",
          headers: {
              "Content-Type": "application/json"
          },
          body: JSON.stringify({
              user_id,
              todos
          })
      }).then(res => res.json())
      return data
    }

    const addTodo = async () => {
        setTodoLabel("Adding...")
        if(!disableAddTodo) {
          setDisableAddTodo(true)

          if(todoValue.trim() == "") {
            alert("Sorry we didn't receive any todo to add...")
            setTodoValue("")
            setIsAddingTodo(false)
            console.log("Todos: ", todos)
            return
        }
            let user_id = user.user_id
            let list = todos
            list.unshift({item: todoValue, finished: false})
            let data = await updateTodos(user_id, list)
            console.log("Data: ", data)
            if(data.success) {
                // alert("Updated todolist!")
                // router.reload()
                setTodoLabel("Submit")
                setTodos(list)
                // return
            } else {
                alert("Error: " + data.error)
            }
            setTodoValue("")
            setIsAddingTodo(false)
            setDisableAddTodo(false)
        }
    }

    console.log(user.country ? "has country" : "has no country")


    const [correspondingCountry, setCorrespondingCountry] = useState("")

    // useEffect(()=>{
    //   if(user.country) setCorrespondingCountry((countries.filter(c => c.code == user.country))[0].name)

    // }, [user.country])

    let hasOneDemogrpahic = false
    hasOneDemogrpahic = Number.isInteger(user.age) || user.country || user.region || Number.isInteger(user.incomeBracket) || Number.isInteger(user.raceEthnicity) || Number.isInteger(user.education) || Number.isInteger(user.pregnancyStatus)
    


    return (
        <div>
          <Navbar user={user}></Navbar>
            <div className={`text-3xl md:text-5xl font-bold mx-auto text-primaryPink text-center mt-8`}>
              <span className='font-semibold semi text-grayPink'>Hey</span> {user.username}
            </div>
            <div className={`secondary font-bold mx-auto text-primaryPink mt-2 text-center`}>
              <span className="text-grayPink font-semibold">Email: </span>{user.email}
            </div>
            <div className={`secondary font-bold mx-auto text-grayPink text-center`}>
              {`${days[(new Date()).getDay()]}, ${(new Date()).toLocaleDateString()}`}
            </div>
          <div className="w-full sm:w-3/4 gap-4 flex flex-col semimd:flex-row mx-auto">
          {/*To-Do List Stuff */}
            <div className="text-3xl md:flex-row text-primaryPink h-min pb-4 text-center bg-lightGreen px-4 py-2 rounded min-w-max w-full sm:w-3/4 mx-auto">
                <div className="flex flex-col">
                  <span className="font-rozhaOne text-3xl md:text-5xl mt-2">To-Do List:</span>
                </div>
                <div className="flex w-4/5 mx-auto flex-col secondary text-primaryPink space-y-2 font-semibold">
                  <div className="max-h-64 h-min space-y-2 px-4 overflow-y-auto">
                    {todos.map((item, i) => (
                          <div key={`todo${i}`} className={`flex group ${ item.finished ? "bg-grayPink" : "bg-primaryPink"} rounded text-white px-2 py-1`}>
                              <input checked={item.finished} onChange={e => markFinished(item, e.target.checked)} type="checkbox" className={`w-3 peer group h-3 my-auto mr-2 appearance-none bg-white checked:bg-unsaturatedPink rounded ring-primaryPink`} /> 
                              <span className={`peer-checked:text-unsaturatedPink ${item.finished ? "line-through" : ""}`}>{item.item.trim().charAt(0).toUpperCase() + item.item.trim().slice(1, item.item.length)}</span>
                              <FontAwesomeIcon onClick={()=>deleteTodo(item)} className="ml-auto cursor-pointer w-4 h-4 my-auto hover:scale-150 transition duration-300 ease-in-out" icon={faXmark}></FontAwesomeIcon>
                          </div>
                      ))}
                  </div>
                    {todos.length == 0 ? <div className="text-gray-400 flex flex-col text-sm"><FontAwesomeIcon className="mt-4 w-8 h-8 mx-auto text-grayPink" icon={faPenNib}></FontAwesomeIcon><span className="text-sm w-3/4 text-center mx-auto mt-2 text-grayPink">Make your first todo today!</span></div> : <></>}
                    <button disabled={isAddingTodo} onClick={() => setIsAddingTodo(true)} className="px-4 py-2 bg-primaryPink text-white mx-auto text-sm rounded disabled:bg-stone-200 hover:bg-rose-400 transition duration-300 ease-in-out">Make a New Todo</button>
                    {isAddingTodo ? <form onSubmit={(e) => {
                          e.preventDefault()
                          addTodo()
                        }} className="mt-6 flex flex-col">          
                        <input type="text" max={30} className="border-b-2 w-full semimd:w-3/4 border-primaryPink mx-2 semimd:mx-auto text-base bg-transparent outline-none text-primaryPink font-semibold" value={todoValue} onChange={e => setTodoValue(e.target.value)} />          
                        <div className="flex space-x-2 mx-auto">
                            <button onClick={addTodo} className="px-4 py-2 mt-2 bg-primaryPink text-white text-sm rounded hover:bg-pink-400 transition duration-300 ease-in-out">{todoLabel}</button>
                            <button onClick={() => setIsAddingTodo(false)} className="px-4 py-2 mt-2 bg-red-400 text-white text-sm rounded hover:bg-rose-500 transition duration-300 ease-in-out">Cancel</button>
                        </div>
                    </form>: <></>}
                </div>
            </div>
          </div>
        </div>
        )
  }