import { withIronSessionSsr } from "iron-session/next"
import { ironOptions } from "@/utils/ironConfig"
import { checkForUser, connectMongo } from "@/utils/api"
import Navbar from "@/components/Navbar"
import { useState } from "react"
import { useRouter } from "next/router"
import {
  ages,
  countries,
  days,
  educationLevels,
  incomeBrackets,
  pregnancyStatuses,
  raceEthnicities,
  subscriptions,
} from "@/utils/standards";
import DisplayStat from "@/components/DisplayStat"
import obtainSessionUser from "@/utils/obtainSessionUser"
import { useGoogleLogin } from "@react-oauth/google"
import Image from "next/image"
import {Head} from "next/head"
import SubscriptionCard from "@/components/SubscriptionCard"

export const getServerSideProps = withIronSessionSsr(async function ({
  req,
  res,
}) {
  await connectMongo();
  if(req.session.user) {
    let mongoUser = await checkForUser(req.session.user.username)
    if(mongoUser) {
      req.session.user = obtainSessionUser(mongoUser)
      await req.session.save()
    }
  }
  console.log("Session User in Profile View: ", req.session.user);
  console.log(`Undefined ${req.session.user === undefined}`)
  if(!req.session.user?.verified) {
    return {
      redirect: {
        destination: '/?reasonKicked=You can\'t access your profile until you verify your email',
        permanent: true,
      },
    }
  }
  if(!req.session.user || req.session.user === undefined || !req.session.user.verified) {
    return {
      redirect: {
        destination: '/',
        permanent: true,
      },
    }
  } 
  return { props: { user: JSON.parse(JSON.stringify(req.session.user)) ?? null } };
},
ironOptions);

  export default function Profile({user}) {
    //Stop reloading when adding/deleting/editing todos and instead handle the payload on window.onbeforeunload (before route changes and etc..)
    console.log("User: ", user)
    const checklist = ["Drink 5 cups of water", "Exercise for 30 minutes", "Go for a walk", "Check in with obgyn"]

    const router = useRouter()
    const [isAddingTodo, setIsAddingTodo] = useState(false)
    const [todoValue, setTodoValue] = useState("")
    const [todos, setTodos] = useState(user.todos ?? [])
    const [todoLabel, setTodoLabel] = useState("Submit")
    const [disableAddTodo, setDisableAddTodo] = useState(false)

    const handleFormSubmit = async ({age = null, country = null, region = null, incomeBracket = null, raceEthnicity = null, personalRaceDefiniton = null, education = null, personalEducationDefinition = null, pregnancyStatus = null, email = null, username = null, password = null, trimester = null, daysIntoTrimester = null}) => {
      console.log({
        trimester,
        daysIntoTrimester,
        username,
        password,
        email,
        age,
        country,
        region: region ? region.trim() : "",
        incomeBracket,
        raceEthnicity,
        personalRaceDefiniton: personalRaceDefiniton ? personalRaceDefiniton.trim() : "",
        education,
        personalEducationDefinition: personalEducationDefinition ? personalEducationDefinition.trim() : "",
        pregnancyStatus,
        trimester,
        daysIntoTrimester
      })
      let data = await fetch("/api/demographics/update", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        
        body: JSON.stringify({
          trimester,
          daysIntoTrimester,
          username,
          password,
          email,
          age,
          country,
          region,
          incomeBracket,
          raceEthnicity,
          personalRaceDefiniton,
          education,
          personalEducationDefinition,
          pregnancyStatus
        })
      }).then(res => res.json())
      if(data.success) {
        alert("Successfully updated demographics")
        return
      } else {
        alert("Failed to update demographics")
      }
      return false
    }

    console.log(user.country ? "has country" : "has no country")


    const [correspondingCountry, setCorrespondingCountry] = useState("")

    // useEffect(()=>{
    //   if(user.country) setCorrespondingCountry((countries.filter(c => c.code == user.country))[0].name)

    // }, [user.country])

    let hasOneDemogrpahic = false
    hasOneDemogrpahic = Number.isInteger(user.age) || user.country || user.region || Number.isInteger(user.incomeBracket) || Number.isInteger(user.raceEthnicity) || Number.isInteger(user.education) || Number.isInteger(user.pregnancyStatus)
    
    const googleLogin = useGoogleLogin({
      onSuccess: async (tokenResponse) => {
        console.log(tokenResponse)
        const userInfo = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
          headers: {
            Authorization: `Bearer ${tokenResponse.access_token}`
          }
        }).then(res => res.json())
        const data = await fetch("/api/google/addGoogleSub", {
          method: "POST",
          headers: {
            "Content-Type":"application/json"
          },
          body: JSON.stringify({
            googleSub: userInfo.sub
          })
        }).then(res => res.json())
        console.log("Data: ", data)
        if(data.success) {
          alert("Added Google Account!")
          router.reload()
          return
        } else {
          alert(`Error: ${data.error}`)
          return
        }
      },
      onError: (error) => {
        console.log(error)
        alert(error)
      }
    })

    return (
        <div>
          <Navbar user={user}></Navbar>
            <div className={`text-3xl md:text-5xl font-bold mx-auto text-primaryPink text-center mt-8`}>
              <span className='font-semibold semi text-grayPink'>Hey</span> {user.username}
            </div>
            <div className={`secondary font-bold mx-auto text-primaryPink mt-2 text-center`}>
              <span className="text-grayPink font-semibold">Email: </span>{user.email} 
            </div>
            <div className={`secondary font-bold mx-auto text-grayPink text-center`}>
              {`${days[(new Date()).getDay()]}, ${(new Date()).toLocaleDateString()}`}
            </div>
          <div className="w-3/4 gap-4 flex flex-col semimd:flex-row mx-auto">
            {
              hasOneDemogrpahic ?
              <div className="w-full text-center mx-auto">
                {
                  Number.isInteger(user.age) || user.country || user.region || Number.isInteger(user.education) || Number.isInteger(user.incomeBracket) || Number.isInteger(user.raceEthnicity) || Number.isInteger(user.pregnancyStatus) ?
                  <div className="ml-4 text-primaryPink mt-8">
                    <div className={`text-3xl semimd:text-5xl lg:text-6xl font-rozhaOne`}>Personal Information:</div>
                  </div> : <></>
                }
                <div className="mx-auto w-min min-w-max text-center">
                  {Number.isInteger(user.age) ? 
                  <DisplayStat type={"number"} updating={"age"} edit={handleFormSubmit} options={ages} selection={true} title={"Age Range:"} stat={user.age}></DisplayStat>
                                  : <></>}
                  {user.country ?  
                  <DisplayStat updating={"country"} edit={handleFormSubmit} type={"text"} options={countries} selection={true} title="Country:" stat={user.country}></DisplayStat>
                  : <></>}
                  {user.region ? 
                    <DisplayStat updating={"region"} edit={handleFormSubmit} type={"text"} title="Region:" stat={user.region}></DisplayStat>
                  : <></>}
                  {Number.isInteger(user.education) ? <>
                  {/* Can have personal */}
                    <DisplayStat type={"number"} updating={"education"} personalTrigger={7} personalDefinition={user.personalEducationDefinition ?? ""} edit={handleFormSubmit} options={educationLevels} selection={true} title="Education:" stat={user.education}></DisplayStat>
                  </> : <></>}
                  {Number.isInteger(user.incomeBracket) ? <>
                    <DisplayStat type={"number"} updating={"incomeBracket"} edit={handleFormSubmit} options={incomeBrackets} selection={true} title="Income Bracket:" stat={user.incomeBracket}></DisplayStat>
                  </> : <></>}
                  {Number.isInteger(user.raceEthnicity) ? <>
                  {/* Can have personal */}
                  <DisplayStat type={"number"} personalTrigger={5} personalDefinition={user.personalRaceDefiniton ?? ""} updating={"raceEthnicity"} edit={handleFormSubmit} options={raceEthnicities} selection={true} title="Race/Ethnicity:" stat={user.raceEthnicity}></DisplayStat>
                  </> : <></>}
                  {Number.isInteger(user.pregnancyStatus) ? <>
                  <DisplayStat type={"number"} updating={"pregnancyStats"} edit={handleFormSubmit} options={pregnancyStatuses} selection={true} title="Pregnancy Status:" stat={user.pregnancyStatus}></DisplayStat>
                  </> : <></>}
      
                </div>
              </div> : 
              <> <div className="mx-auto text-grayPink mt-8">
              <div className={`text-xl text-center semimd:text-3xl lg:text-4xl font-semibold`}>Fill out the questionnaire on the Home Page</div>
            </div></>
            }
          </div>
          {
            user.googleSub ? <></> : 
            <div className="flex mt-8 mx-auto w-min min-w-max flex-col">
              <div className="secondary font-bold text-primaryPink underline decoration-2 decoration-unsaturatedPink">
                Setup Login With:
              </div>
              <div className="space-x-2 flex">
                <button className='mt-4 mx-auto' onClick={googleLogin}>
                  <Image src="/google.png" className="w-7 h-7 md:w-8 md:h-8 hover:scale-110 transition-all duration-300 ease-in-out" height={75} width={75} />
                  {/* <div className='ml-2 small text-gray-400 font-semibold'>
                    Sign in with Google
                  </div> */}
                </button>
              </div>
            </div>
          }
          <p className="text-center mx-auto semi font-semibold mt-8">
            <span className="text-grayPink">Subscription:</span> <span className="text-primaryPink">{subscriptions[user.subscription].title}</span>
          </p>

          <div className="flex gap-4 mt-4 mb-8 w-3/4 mx-auto">

            {
              subscriptions.map((subscription, i) => (
                <SubscriptionCard key={`card${i}`} activeSubscription={user.subscription} split={subscriptions.length} subscription={subscription} />
              ))
            }
          </div>
        </div>
        )
  }