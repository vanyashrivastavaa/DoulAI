import ComingSoon from "@/components/ComingSoon";
export default function Page() {
  return (
    <ComingSoon message={"Coming soon to Android and IOS"}/>
  );
}
