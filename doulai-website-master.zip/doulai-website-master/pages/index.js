import Navbar from "@/components/Navbar";
import { withIronSessionSsr } from "iron-session/next";
import { ironOptions } from "@/utils/ironConfig";
import { checkForUser, connectMongo } from "@/utils/api";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/router";
import { redirect, useSearchParams } from 'next/navigation'
import DemographicsForm from "@/components/DemographicsForm";
import obtainSessionUser from "@/utils/obtainSessionUser";
import Image from "next/image";
import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { faArrowDown, faClipboard, faSpinner } from "@fortawesome/free-solid-svg-icons";
import { faGooglePlay, faAppStoreIos } from "@fortawesome/free-brands-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";


export const getServerSideProps = withIronSessionSsr(async function ({
  req,
  res,
}) {
  await connectMongo();
  if(req.session.user) {
    const user = await checkForUser(req.session.user.username)
    console.log("User from MongoDb at index: ", user)
    // if(user) {
    //   delete user.key
    //   delete user.salt
    //   console.log("User: ", user)
    //   console.log("Key: " + user.keys)
    //   req.session.user = user
    //   await req.session.save()
    // }
    if(user) {
      req.session.user = obtainSessionUser(user)
      await req.session.save()
    }
  }
  console.log("Session User: ", req.session.user);
  return { props: { user: req.session.user ? JSON.parse(JSON.stringify(req.session.user)) : null } };
},
ironOptions);

export default function Page({ user }) {
  useEffect(()=> {
    console.log("User: ", user)
    console.log("What up dawg")
  }, [])

  const router = useRouter()
  const searchParams = useSearchParams()

  const [hasAllDemographics, setHasAllDemographics] = useState(false)
  const [errorMessage, setErrorMessage] = useState(searchParams.get("message"))
  const [showDemographics, setShowDemographics] = useState(false)
  const [verifying, setVerifying] = useState(false)
  const timeoutRef = useRef()


  // console.log("User: ", user);

  useEffect(() => {
    if(user && typeof user !== 'undefined') {
      //Initial check
      let hasAll = Number.isInteger(user.age) && user.country && user.region && Number.isInteger(user.incomeBracket) && Number.isInteger(user.raceEthnicity) && Number.isInteger(user.education) && Number.isInteger(user.pregnancyStatus)
      setHasAllDemographics(hasAll)
      
      if(user.pregnancyStatus == 1 || user.pregnancyStatus == 2) {
        console.log("Checking pregnant status")
        setHasAllDemographics(hasAll && Number.isInteger(user.trimester) && Number.isInteger(user.daysIntoTrimester))
      }
      if(user.education == 7) {
        console.log("Checking Education Def: ", user.personalEducationDefinition)
        console.log(hasAll)
        console.log(hasAll && user.personalEducationDefinition)
        setHasAllDemographics(hasAll && user.personalEducationDefinition)
      }
      if(user.raceEthnicity == 5) {
        console.log("Checking Race Def: ", user.personalRaceDefiniton)
        console.log(hasAll)
        console.log(hasAll && user.personalRaceDefiniton)
        setHasAllDemographics(hasAll && user.personalRaceDefiniton)
      }
    }
  
    console.log("Has All Demographics: ", hasAllDemographics)
    return () => clearTimeout(timeoutRef.current)
  }, [])

  const verifyEmail = async (email) => {
    setVerifying(true)
    console.log("Verifying Email: " + email)
    console.log("Id sent: " + user._id)
    let data = await fetch("/api/verify", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        userObjectId: user._id,
        email: user.email
      })
    }).then(res => res.json())
    console.log("Verification Date: ", data)
    if(data.success) {
      alert(`Just sent verification email to ${email}`)
    } else {
      alert("Something went wrong...")
    }
    setVerifying(false)
    return
  }

  const handleFormSubmit = async ({age, country, region, incomeBracket, raceEthnicity, personalRaceDefiniton, education, personalEducationDefinition, pregnancyStatus, trimester, daysIntoTrimester}) => {
    console.log({
      trimester,
      daysIntoTrimester,
      age,
      country,
      region: region.trim(),
      incomeBracket,
      raceEthnicity,
      personalRaceDefiniton: personalRaceDefiniton.trim(),
      education,
      personalEducationDefinition: personalEducationDefinition.trim(),
      pregnancyStatus
    })
    let data = await fetch("/api/demographics/update", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        trimester,
        daysIntoTrimester,
        age,
        country,
        region: region.trim(),
        incomeBracket,
        raceEthnicity,
        personalRaceDefiniton: personalRaceDefiniton.trim(),
        education,
        personalEducationDefinition: personalEducationDefinition.trim(),
        pregnancyStatus
      })
    }).then(res => res.json())
    if(data.success) {
      alert("Successfully updated demographics")
      setShowDemographics(false)
      setHasAllDemographics(true)
      router.push("/")
      return
    } else {
      alert("Failed to update demographics")
    }
    return false
  }


  // const firstBanner = "https://images.unsplash.com/photo-1431263154979-0982327fccbb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80"
  const firstBanner = "/heroes/pregnantMotherHeart.jpg"
  const link = "/appPreview"

  return (
    <div> 
      <Navbar user={user}></Navbar>
      <div style={{backgroundImage: `url(${firstBanner})`}} className={` h-80 sm:h-96 lg:h-[500px] xl:h-[600px] flex text-start bg-center bg-cover bg-fixed`}>
          <div className="flex flex-col align-middle mt-10 sm:mt-20 text-center sm:text-start mx-auto sm:ml-16 lg:ml-24 xl:ml-36 primary xl:text-8xl text-white font-antiqua w-5/6 sm:w-2/3 xl:w-3/4">
            The Future of Maternal Healthcare is Here. Experience Health and Wellness with DoulAI.
            <span className="secondary font-questrial">
              SELF-SERVICING MATERNAL CARE APPLICATION
            </span>
          </div>
          <span >
          </span>
      </div>
      <div className="text-center text-primaryPink mt-16">
        <div className="secondary font-sans">Our Features</div>
        <div className=" primary font-antiqua font-semibold w-1/2 mx-auto">
        Affordable. Accurate. Accessible.
        </div>
        <div className="mt-8 mx-auto gap-2 flex flex-col md:flex-row justify-between w-4/5">
          <ProductCard user={user} title={"Blogs"} link={"/blogs"} image={"blogs.jpg"} />
          <ProductCard user={user} title={"Task List"} link={"/profile"} image={"tasklist.jpg"} />
          <ProductCard user={user} title={"Chatbot"} link={"/chat"} image={"chatbot.jpg"} />
        </div>
        <div className="my-80 flex flex-col">
          <div className="primary font-antiqua w-full sm:w-1/2 mx-auto">
            Download our App Today
          </div>
          <FontAwesomeIcon icon={faArrowDown} className="text-grayPink w-11 mx-auto h-11 animate-bounce mt-4" />
          <Link className="mt-6 flex space-x-8 justify-between w-min min-w-max mx-auto hover:scale-110 duration-300 ease-in-out transition" href={link}>
            <FontAwesomeIcon icon={faAppStoreIos} className="text-primaryPink w-20 h-20 mt-4" />
            <FontAwesomeIcon icon={faGooglePlay} className="text-primaryPink w-20 h-20 mt-4" />

          {/* <FontAwesomeIcon icon={faAppStoreIos} className="text-grayPink w-12 h-12 animate-bounce mt-4" /> */}
          </Link>
        </div>
        <div className="my-48">
          <div className="secondary font-sans">Here at DoulAi, We Believe That</div>
          <div className="primary font-antiqua w-full sm:w-1/2 mx-auto">
            The power of support transforms pregnancy challenges into achievable milestones.
          </div>
        </div>
        <div className="fixed bottom-2 right-2 flex gap-2">
          {
            user ?
            (!user.verified ?  
            <button className="font-semibold flex hover:bg-secondaryPink transition duration-300 ease-in-out bg-primaryPink text-white rounded px-4 py-4 secondary" onClick={()=>verifyEmail(user.email)}>
              {!verifying ? "Verify Your Email" : <div className="flex">
              <FontAwesomeIcon className="w-5 h-5 animate-spin text-pink-200 my-auto mr-2" icon={faSpinner}></FontAwesomeIcon>
              Verifying
              </div>} <span><FontAwesomeIcon className="text-white my-auto ml-2" icon={faClipboard}></FontAwesomeIcon></span>
            </button>
            : <></>) : null
          }
          {
            user ? ((user && !hasAllDemographics) || (!user)) && !showDemographics ?
            <button className="font-semibold flex hover:bg-secondaryPink transition duration-300 ease-in-out bg-primaryPink text-white rounded px-4 py-4 secondary" onClick={() => setShowDemographics(true)}>
              Begin Your Questionnaire <span><FontAwesomeIcon className="text-white my-auto ml-2" icon={faClipboard}></FontAwesomeIcon></span>
            </button> : <></> : null
          }
        </div>
      </div>
      {
        showDemographics ?
        <DemographicsForm setShowDemographics={setShowDemographics} handleFormSubmit={handleFormSubmit} user={user}/>
        : <></>
      }
    </div>
  );
}
