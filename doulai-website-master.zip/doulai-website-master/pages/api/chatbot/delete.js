import { ironOptions } from "@/utils/ironConfig";
import { loginUser, connectMongo, addToGptHistorySection, checkForUser, getGptHistory, deleteGptHistory } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";
import { OpenaiBot, openAiBot } from "@/utils/gpt";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    //TODO: Add messsage history unique to user
    //TODO: Add separate tabs like with ChatGPT
    await connectMongo()

    let { username } = req.body
    
    let user = await checkForUser(req.session.user.username)
    await deleteGptHistory(user._id)
}