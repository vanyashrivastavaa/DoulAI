import { ironOptions } from "@/utils/ironConfig";
import { checkForUser, connectMongo, deleteTokenFor, findResetToken, findToken, updateUser, updateUserVerification } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import obtainSessionUser from "@/utils/obtainSessionUser";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()
    // console.log("Why you no work")
    let { id } = req.query
    console.log(`Id: ${id}`)
    let token = await findResetToken(id)
    if(!token) {
        return res.send({success: false})
    }
    console.log("Token: ", token)
    let user = await checkForUser(null, token.user_id)
    if(user) {
        return res.send({success: true, user: obtainSessionUser(user)})
    }
    return res.send({success: false})
}