import { ironOptions } from "@/utils/ironConfig";
import { loginUser, connectMongo, makeTokenFor, makeResetTokenFor, checkForUser } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()
    let { email } = req.body
    let user = await checkForUser(email)
    if(!user) return res.json({success: false, error: "Account doesn't exist"})
    let verification = await makeResetTokenFor( user._id )

    if(verification.success) {
        let token = verification.token
        // console.log(`Token: `, token)
        await sendEmail(email, "Reset your password with Doul Ai", `
        <p>Your link is <a href="${process.env.LISTED_URL}/reset/${token.token}">${process.env.LISTED_URL}/reset/${token.token}</a>, this will be valid for an hour</p>
        <p>*Note that other links will be invalid</p>
        `)
        return res.json({success: true})
    }
    return res.json({success: false, error: "Something went wrong"})
}