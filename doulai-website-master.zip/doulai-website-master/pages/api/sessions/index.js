import { ironOptions } from "@/utils/ironConfig";
import { loginUser, connectMongo, getUserAiSession, setAiSession, addToGptHistorySection } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()

    if(req.method == "GET") {
        let user_id = req.session.user.user_id
    
        let openSession = await getUserAiSession(user_id) 
    
        return res.json({success: true, openSession})
    } else if(req.method == "POST") {
        let { status, gptHistory } = req.body

        console.log("Updating......, status is ", status)
        console.log(req.session.user._id)
        if(gptHistory && gptHistory?.length > 0) {
            console.log("History passed")
            console.log(gptHistory)
            await addToGptHistorySection(req.session.user._id, 0, null, gptHistory)
        }
        let updated = await setAiSession(req.session.user.user_id, status)
        console.log(`Updated`, updated)
        if(updated) return res.json({success: true})
        return res.json({success: false})
    }
}