import { ironOptions } from "@/utils/ironConfig";
import { loginUser, connectMongo, getUserAiSession } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()

    let {user_id} = req.body

    let sessions = await getUserAiSession(user_id) 

    return res.json({success: true, sessions})
}