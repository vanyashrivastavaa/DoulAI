import { ironOptions } from "@/utils/ironConfig";
import { loginUser, connectMongo, updateUser, updateTodos, checkForUser, updateUserDay } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";
import { finished } from "nodemailer/lib/xoauth2";
import obtainSessionUser from "@/utils/obtainSessionUser";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()
    if(!req.session.user) return res.json({success: false, error: "No user logged in"})
    let curr = await checkForUser(null, req.session.user._id)
    // console.log("MongoDB User: ", curr)

    //Affecting todos by checking what day it is
    if(curr) {
        let userDate = curr.currentDay
        if(!(userDate instanceof Date)) {
            console.log("No current day or no date stored")
            let newDate = (new Date())
            console.log("Date Created: ", newDate)
            let updated = await updateUserDay(curr.user_id, newDate)
            console.log("updated: ", updated)
            if(updated) curr = updated
        } else {
            console.log("Already has a current day")
        }
        userDate = curr.currentDay
        console.log("Current Day: " + curr.currentDay)
        let computerDate = (new Date())
        console.log(`User Date: ${userDate}, Computer Date ${computerDate}`)
        let sameDay = (new Date()).getDay() == (new Date(userDate)).getDay()
        if(!sameDay) {
            console.log("Different days")
            let updated = await updateUserDay(curr.user_id, computerDate)
            if(curr.todos) {
            let todos = curr.todos
            todos = todos.map((todo) => {
                return {item: todo.item, finished: false}
            })
            await updateTodos(curr.user_id, todos)
            }
            return res.json({success: true, reload: true})
        } else {
            console.log("Is the same day!")
        }
    
        //Resetting the session user
        // console.log("Curr: ", curr)
        req.session.user = obtainSessionUser(curr)
        await req.session.save()
    }
    // console.log("Session User Now: ", req.session.user)
    return res.send({success: true})
}