import { connectMongo, createUser, updateDemographics } from "@/utils/api";
import { ironOptions } from "@/utils/ironConfig";
import { withIronSessionApiRoute } from "iron-session/next";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
  await connectMongo()
        //logged in user
        let updates = req.body
        updates.user_id = req.session.user.user_id
        console.log("User is already logged in")
        console.log("Session: ", req.session.user)
        let updated = await updateDemographics(updates)
          console.log("Updated: ", updated)
          updated.key = null
          updated.salt = null
          req.session.user = updated
          await req.session.save()
          if(updated) {
            return res.json({success: true})
          } 
          return res.json({success:false, error: "Failed to update user demographics"})
}