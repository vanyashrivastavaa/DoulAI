import { ironOptions } from "@/utils/ironConfig";
import { changePasswordOf, checkForUser, connectMongo, deleteTokenFor, findResetToken, findToken, updateUser, updateUserVerification } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import obtainSessionUser from "@/utils/obtainSessionUser";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()
    // console.log("Why you no work")
    let { link, password } = req.body
    console.log(`Id for Forgot Password: ${link}`)
    let token = await findResetToken(link)
    if(!token) {
        return res.send({success: false, error: "Reset link may have expired, try again"})
    }
    console.log("Token: ", token)
    let user = await checkForUser(null, token.user_id)
    console.log("user: ", user)
    if(user) {
        let updated = await changePasswordOf(user._id, password)
        console.log("New user after resetting password: ", updated)
        return res.send({success: true})
    }
    return res.send({success: false, error: "Couldn't find user"})
}