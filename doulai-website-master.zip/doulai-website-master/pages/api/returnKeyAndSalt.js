import { deriveKeyFromPassword } from "@/utils/encryptPassword"

export default async function handler(req, res) {
    let {password} = req.query
    console.log("Password: ", password)
    console.log(await deriveKeyFromPassword(password))
}