import { ironOptions } from "@/utils/ironConfig";
import { withIronSessionApiRoute } from "iron-session/next"

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    req.session.destroy();
    await req.session.save();
    console.log("Session User should be Cleared: ", req.session.user)
    res.redirect('/')
}