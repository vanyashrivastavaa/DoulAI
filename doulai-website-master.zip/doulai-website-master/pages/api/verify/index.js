import { ironOptions } from "@/utils/ironConfig";
import { loginUser, connectMongo, makeTokenFor } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()
    let { userObjectId, email } = req.body
    if(!userObjectId) return res.json({success: false, error: "Didn't pass in any user object id"})
    let verification = await makeTokenFor( userObjectId )

    if(verification.success) {
        let token = verification.token
        // console.log(`Token: `, token)
        await sendEmail(email, "Confirm your Email with Doul Ai", `
        <h1><strong>Confirm your email with DoulAi</strong></h1>
        <p>Your link is <a href="${process.env.LISTED_URL}/verify/${token.token}">${process.env.LISTED_URL}/verify/${token.token}</a>, this will be valid for an hour</p>
        <p>*Note that other links will be invalid</p>
        `)
        return res.json({success: true})
    }
    return res.json({success: false, error: "Something went wrong"})
}