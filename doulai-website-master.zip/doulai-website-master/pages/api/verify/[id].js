import { ironOptions } from "@/utils/ironConfig";
import { checkForUser, connectMongo, deleteTokenFor, findToken, updateUser, updateUserVerification } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import obtainSessionUser from "@/utils/obtainSessionUser";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()
    // console.log("Why you no work")
    let { id } = req.query
    console.log(`Id: ${id}`)
    let token = await findToken(id)
    if(!token) {
        return res.send({success: false})
    }
    console.log("Token: ", token)
    let user = await checkForUser(null, token.user_id)
    console.log("Session User: ", req.session.user)
    // console.log("User found for Verification: ", user)
    if(user) {
        let updated = await updateUserVerification(user.user_id, true)
        // console.log("Updated: ", updated)
        if(updated.verified) req.session.user.verified = true
        await deleteTokenFor(user.user_id)
        req.session.user = obtainSessionUser(updated)
        console.log("Obtained User: ", obtainSessionUser(updated))
        await req.session.save()
        console.log("Session: ", req.session.user)
        return res.send({success:true})
        //This user actually exists
    }
    return res.send({success: false})

}