import { ironOptions } from "@/utils/ironConfig";
import { createUser, connectMongo, makeTokenFor } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";
import obtainSessionUser from "@/utils/obtainSessionUser";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()
    let { username, email, password, googleProfile } = req.body;
    // console.log("Info: ", { username, email, password })
    let user = {}
    user.username = username
    user.email = email
    user.password = password
    if(googleProfile) {
        //Setting necessary google stuff
        user.email = googleProfile.email
        user.googleSub = googleProfile.sub
        user.verified = googleProfile.email_verified
    }
    // user.password = password
    let data = await createUser(user);
    //Will become its own verification route

    if(data.success) {
        // console.log("Created User: ", data.user)
        data.alreadyVerified = true

        if(!user.verified) {
            //The case when making an account and the oauth says email is verified
            
            let verification = await makeTokenFor( data.user._id )
            
            if(verification.success) {
                let token = verification.token
                console.log(`Token: `, token)
                await sendEmail(email, "Confirm your Email with Doul Ai", `
                <h1><strong>Confirm your email with DoulAi</strong></h1>
                <p>Your link is <a href="${process.env.LISTED_URL}/verify/${token.token}">${process.env.LISTED_URL}/verify/${token.token}</a>, this will be valid for an hour</p>
                <p>*Note that other links will be invalid</p>
                `)
            }
            data.alreadyVerified = false
        }

        req.session.user = obtainSessionUser(data.user)
        await req.session.save()
        // console.log("Session: ", req.session.user)
        res.send(data)
    } else {
        console.log("Error: ", data.error)
        res.send(data)
    }
}