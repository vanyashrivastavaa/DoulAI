import { ironOptions } from "@/utils/ironConfig";
import { connectMongo, updateTodos } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    await connectMongo()
    let { user_id, todos } = req.body;
    console.log({ user_id, todos })
    let data = await updateTodos(user_id, todos)
    console.log("Todos: ", data.todos)
    if(data.success) {
        console.log("All is well")
        req.session.user.todos = data.todos
        console.log("New Session: ", req.session.user)
        await req.session.save()
        return res.send({success: true})
    } else {
        return res.send({ success: false, error: data.error })
    }
}