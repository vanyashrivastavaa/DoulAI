import { ironOptions } from "@/utils/ironConfig";
import { loginUser, connectMongo, checkForGoogleUser } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";
import obtainSessionUser from "@/utils/obtainSessionUser";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    console.log("Logging in")
    await connectMongo()
    console.log(req.body)
    let { usernameOrEmail, password, googleProfile } = req.body;
    if(googleProfile) {
        //Log in via google oauth
        let data = await checkForGoogleUser(googleProfile.sub)
        console.log("Google User: ", data)
        if(!data) return res.json({success: false, error: "Don't recognize a user registered with that google account"})
        req.session.user = obtainSessionUser(data)
        await req.session.save()
        return res.json({success: true})
    } else {
        let data = await loginUser(usernameOrEmail, password);
        if(!usernameOrEmail || !password) {
            console.log("Error: Don't have all fields")
            return res.json({success: false, error: "Didn't get all required fields"})
        }
        if(data.success) {
            console.log("Logged In User: ", data.user)
            console.log("Logged in!")
            data.user.key = null
            data.user.salt = null
            req.session.user = data.user
            console.log("Logged In Session User: ", req.session.user)
            await req.session.save()
            res.send(data)
        } else {
            console.log("Error: ", data.error)
            res.send(data)
        }
    }
}
