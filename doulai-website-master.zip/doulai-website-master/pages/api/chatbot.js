import { ironOptions } from "@/utils/ironConfig";
import { loginUser, connectMongo, addToGptHistorySection, checkForUser, getGptHistory } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";
import { OpenaiBot, openAiBot } from "@/utils/gpt";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    //TODO: Refine chatGPT messags with specific system message, personality message, demographisc message, and standard messages
    //TODO: Add separate tabs like with ChatGPT
    try {
        await connectMongo()
        
        let content = []
    
        console.log(req.body)
        let { query, sectionName, gptHistory } = req.body
        console.log(gptHistory)
        console.log(query)    
        // let user = await checkForUser(req.session.user.username)
    
        // let pastQuestions = await getGptHistory(user._id)
        // if(pastQuestions) {
        //     let sectionContent = pastQuestions.sections[0].content
        //     sectionContent = sectionContent.map(s => {return {role: s.role, content: s.content}})
        //     console.log("Section Content: ", sectionContent)
        gptHistory = gptHistory.map(s => {return {role: s.role, content: s.content}})
        openAiBot.setMessages(gptHistory)
        // }
        console.log("Sending")
        let response = await openAiBot.question(query)

        //We have user and assistant roles
        let messagesToSave = openAiBot.messages.slice(0, 25)
        console.log("Messages: ", messagesToSave) //obtains the 50 responses we'll be saving
        // await addToGptHistorySection(user._id, 0, null, messagesToSave)
        //Need to add some error handling
        return res.json({success: true, response})
    } catch (error) {
        console.log("Error: ", error)
        return res.json({success: false})
    }
}