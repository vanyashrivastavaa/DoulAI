import { ironOptions } from "@/utils/ironConfig";
import { loginUser, connectMongo, checkForGoogleUser, updateUserGoogleSub } from "@/utils/api"
import { withIronSessionApiRoute } from "iron-session/next"
import { sendEmail } from "@/utils/mailing";
import obtainSessionUser from "@/utils/obtainSessionUser";

export default withIronSessionApiRoute(handler, ironOptions)

async function handler(req, res) {
    console.log("Logging in")
    await connectMongo()
    let {googleSub} = req.body
    try {
        console.log("User Id: ", req.session.user.user_id)
        console.log("Google Sub: ", googleSub)
        const user = await updateUserGoogleSub(req.session.user.user_id, googleSub)
        console.log("You made it")
        req.session.user = obtainSessionUser(user)
        await req.session.save()
        return res.json({success: true})
    } catch (error) {
        console.log("Error: ", error)
        return res.json({success: false, error})
    }
}
