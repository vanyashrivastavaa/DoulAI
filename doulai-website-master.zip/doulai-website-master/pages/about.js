import ComingSoon from "@/components/ComingSoon";

export default function Page() {
  return (
    <ComingSoon message={"Under wraps for now..."} />
  );
}
