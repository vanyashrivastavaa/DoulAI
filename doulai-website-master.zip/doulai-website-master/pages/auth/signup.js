import Navbar from "@/components/Navbar";
import { useState } from "react";
import { useRouter } from "next/router";
import Spinner from "@/components/Spinner";
import Link from "next/link";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faXmark } from "@fortawesome/free-solid-svg-icons";
import { useGoogleLogin } from "@react-oauth/google";
import Image from "next/image";

export default function Page() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitDisabled, setSubmitDisabled] = useState(false);
  const [googleProfile, setGoogleProfile]= useState(null)
  const [showingGoogleModal, setShowingGoogleModal] = useState(false)
  const [googleLoading, setGoogleLoading] = useState(false)
  const [googleDisabled, setGoogleDisabled] = useState(false)
  const [agreed, setAgreed] = useState(false)

  const signup = async ({username, email, password, googleProfile}) => {
    
    let data = await fetch("/api/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username,
          email,
          password,
          googleProfile
        }),
      }).then((res) => res.json());
      return data
  }

  const handleSubmit = async () => {
    setLoading(true);
    setUsername("");
    setEmail("");
    setPassword("");

    let data = await signup(username, email, password)

    if (data?.success) {
      alert("Successfully created user and emailed a verification code");
      router.push("/");
      return;
    }

    //Error code
    alert(`Failed to create user, encountered error: ${data.error}`);
    setLoading(false);
  };

  const handleGoogleSubmit = async () => {
    setGoogleLoading(true);
    setUsername("");
    setEmail("");
    setPassword("");

    let data = await signup({username, password, googleProfile})

    if (data?.success) {
    
      if(!data.alreadyVerified) {
        alert("Successfully created user and emailed a verification code");
      } else {
        alert("Successfully created user!")
      }
      router.push("/");
      return;
    }

    //Error code
    alert(`Failed to create user, encountered error: ${data.error}`);
    setGoogleLoading(false);
    setShowingGoogleModal(false)
    setGoogleDisabled(false)
    setSubmitDisabled(false)
    setGoogleProfile({})
  };

  const googleSignup = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      //Set initial stuff
      console.log(tokenResponse);
      const userInfo = await fetch(
        "https://www.googleapis.com/oauth2/v3/userinfo",
        {
          headers: {
            Authorization: `Bearer ${tokenResponse.access_token}`,
          },
        }
      ).then((res) => res.json());
      console.log(userInfo);
      console.log("Unique Identifier: ", userInfo);

      setSubmitDisabled(true)
      setGoogleProfile(userInfo)
      setShowingGoogleModal(true)
      setGoogleDisabled(true)
    },
    onError: (error) =>{
            alert("Something went wrong")
            console.log(error)
        },
  });

  return (
    <div className="h-screen flex items-center">
      <Link href={"/"}>
        <FontAwesomeIcon
          className="w-8 h-8 hover:text-unsaturatedPink duration-300 transition ease-in-out fixed cursor-pointer text-primaryPink top-4 right-4"
          icon={faXmark}
        ></FontAwesomeIcon>
      </Link>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if(agreed) {
            handleSubmit()
          } else {
            alert("Please agree to the Terms and Conditions to create an account")
          }

        }}
        className={`mt-8 w-4/5 sm:w-5/12 bg-lightGreen mx-auto px-10 py-6 text-center rounded font-playfair`}
      >
        <div className="primary text-center font-antiqua text-primaryPink mx-auto font-bold">
          Signup
        </div>
        <div className="text-center w-full text-primaryPink flex flex-col items-center">
          <label htmlFor="" className="text-lg">
            Username:
          </label>
          <input
            required
            onChange={(e) => setUsername(e.target.value)}
            value={username}
            type="text"
            className="pb-0.5 border-b-2 border-primaryPink bg-inherit outline-none w-1/2"
          />
          <label htmlFor="" className="text-lg">
            Email:
          </label>
          <input
            type="email"
            required
            onChange={(e) => setEmail(e.target.value)}
            value={email}
            className="pb-0.5 border-b-2 border-primaryPink bg-inherit outline-none w-1/2"
          />
          <label htmlFor="" className="text-lg">
            Password:
          </label>
          <input
            required
            onChange={(e) => setPassword(e.target.value)}
            value={password}
            type="password"
            className="pb-0.5 border-b-2 border-primaryPink bg-inherit outline-none w-1/2"
          />
          <div className="flex align-baseline text-grayPink small mt-2">
          <input onClick={(e) => {
            console.log(!agreed)
            setAgreed(!agreed)
          }} className="appearance-none my-auto mr-2 h-3 w-3 md:h-4 md:w-4 border-2 rounded border-primaryPink checked:border-grayPink checked:bg-grayPink" checked={agreed} value={agreed} type="checkbox" name="" id="" />
          Agree to <Link className="ml-1 hover:text-primaryPink underline decoration-2 transition-all duration-300 ease-in-out font-bold" href={"/tac"}>Terms and Conditions</Link>
          </div>

          <button
            disabled={submitDisabled}
            type="submit"
            className={`px-4 py-2 flex text-white disabled:bg-primaryPink bg-pink-300 hover:bg-pink-400 transtion duration-300 ease-in-out rounded mt-2`}
          >
            {!loading ? (
              "Submit"
            ) : (
              <>
                <div className="text-white mr-2 flex my-auto w-4 h-4">
                  <Spinner></Spinner>
                </div>
                Loading...
              </>
            )}
          </button>
        </div>
        <Link
          href={"/auth/login"}
          className="text-grayPink flex mx-auto w-min min-w-max font-sans cursor-pointer hover:text-primaryPink duration-300 ease-in-out transition font-bold"
        >
          Login
        </Link>
      <div className="flex mt-8 flex-col">
        <div className="secondary font-bold text-primaryPink underline decoration-2 decoration-unsaturatedPink">
          Sign up with:
        </div>
        <div className="space-x-2 flex">
          <button disabled={googleDisabled} className="mt-4 mx-auto" onClick={googleSignup}>
            <Image
              src="/google.png"
              className={`w-7 h-7 md:w-8 md:h-8 hover:scale-110 transition-all duration-300 ease-in-out`}
              height={75}
              width={75}
            />
          </button>
        </div>
      </div>
      </form>
      {
          showingGoogleModal ?
          <div className="fixed w-full left-0 top-0 h-full bg-black/30">
          <form onSubmit={(e) => {
            e.preventDefault()
            handleGoogleSubmit()
          }} className='bg-lightEarth text-primaryPink flex flex-col px-4 py-4 w-5/6 sm:w-2/3 lg:w-1/3 text-center rounded mt-48 mx-auto' action="">
            <div className="semi font-bold">
                Google Sign Up
            </div>
            <div className="secondary font-semibold">
                <span className="text-grayPink">Hi</span> {googleProfile.name} <span className="text-grayPink">({googleProfile.email})</span>
            </div>
            <label htmlFor="" className="text-lg">
            Username:
          </label>
          <input
            required
            onChange={(e) => setUsername(e.target.value)}
            value={username}
            type="text"
            className="pb-0.5 border-b-2 mx-auto border-primaryPink bg-inherit outline-none w-1/2"
          />
          <label htmlFor="" className="text-lg">
            Password:
          </label>
          <input
            required
            onChange={(e) => setPassword(e.target.value)}
            value={password}
            type="password"
            className="pb-0.5 border-b-2 mx-auto border-primaryPink bg-inherit outline-none w-1/2"
          />
            <div className="flex w-min min-w-max gap-2 mx-auto">
              <button className='bg-pink-300 hover:bg-pink-400 duration-300 ease-in-out transition text-white px-2 py-1 mx-auto w-min rounded mt-4' type="submit">
              {!googleLoading ? "Submit" : <div className='text-white flex'>
                      <div className='text-white mr-2 flex my-auto w-4 h-4'>
                          <Spinner></Spinner>
                      </div>
                      Loading...
                      </div>}
              </button>
              <button onClick={() => {
                setShowingGoogleModal(false)
                setGoogleLoading(false)
                setGoogleDisabled(false)
                setSubmitDisabled(false)
                setGoogleProfile({})
                setUsername("")
                setPassword("")
              }} className='bg-red-400 hover:bg-red-500 duration-300 ease-in-out transition text-white px-2 py-1 mx-auto w-min rounded mt-4' type="submit">
                Close
              </button>
            </div>
          </form>
          </div>
          : 
          <>
          </>
        }
    </div>
  );
}
