import Navbar from '@/components/Navbar'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import Spinner from '@/components/Spinner'
import Link from 'next/link'
import Modal from "react-modal"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faXmark } from '@fortawesome/free-solid-svg-icons'
import { GoogleLogin, GoogleOAuthProvider, useGoogleLogin } from '@react-oauth/google'
import { faGoogle } from '@fortawesome/free-brands-svg-icons'
import Image from 'next/image'

export default function Page() {
  const router = useRouter()
  const [usernameOrEmail, setUsernameOrEmail] = useState("")
  const [password, setPassword] = useState("")
  const [submitDisabled, setSubmitDisabled] = useState(false)
  const [forgotDisabled, setForgotDisabled] = useState(false)
  const [forgotLoading, setForgotLoading] = useState(false)
  const [loadingReset, setLoadingReset] = useState(false)
  const [loading, setLoading] = useState(false)
  const [showingModal, setShowingModal] = useState(false)
  const [forgotEmail, setForgotEmail] = useState("")

  useEffect(()=>{
    console.log(`${process.env.CLIENT_ID}`)
  }, [])

  const login = async ({usernameOrEmail, password, googleProfile}) => {
    let data = await fetch("/api/login", {
      method: "POST",
      headers: {
          "Content-Type": "application/json"
      },
      body: JSON.stringify({
          usernameOrEmail,
          password,
          googleProfile
      })
    }).then(res => res.json())
    return data
  }

  const handleSubmit = async () => {
    setLoading(true)
    setSubmitDisabled(true)
    setUsernameOrEmail("")
    setPassword("")

    let data = await login({usernameOrEmail, password: password.replace(" ", "")})

    if(data.success){
      router.push("/")
      return
    }

    //error code
    setLoading(false)
    alert(`Failed to login, Error: ${data.error}`)
    setSubmitDisabled(false)
  }

  const forgotPassword = async () => {
    setForgotDisabled(true)
    setForgotLoading(true)
    setLoadingReset(true)

    let data = await fetch("/api/reset", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email: forgotEmail
      })
    }).then(res => res.json())
    console.log("Reset Password Data: ", data)
    if(data.success) {
      alert(`Just sent reset email to ${forgotEmail}`)
    } else {
      alert("Something went wrong... There may be no account associated with this email")
    }

    setForgotDisabled(false)
    setForgotLoading(false)
    setShowingModal(false)
    setLoadingReset(false)
    // setTimeout(() => {
    // }, 5000)
  }

  const googleLogin = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      //Set initial stuff
      setLoading(true)
      setSubmitDisabled(true)
      setUsernameOrEmail("")
      setPassword("")

      console.log(tokenResponse)
      const userInfo = await fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
        headers: {
          Authorization: `Bearer ${tokenResponse.access_token}`
        }
      }).then(res => res.json())
      console.log(userInfo) 
      console.log("Unique Identifier: ", userInfo.sub)
      let data = await login({googleProfile: userInfo}) 
      console.log("Data: ", data)
      
      if(data.success){
        router.push("/")
        return
      }

      //error code
      setLoading(false)
      alert(`Failed to login, Error: ${data.error}`)
      setSubmitDisabled(false)
    },
    onError: (error) =>{
      alert("Something went wrong")
      console.log(error)
  },
  })

  return (
    <div className='flex items-center h-screen'>
      <Link href={"/"}>
        <FontAwesomeIcon className="w-8 h-8 hover:text-unsaturatedPink duration-300 transition ease-in-out fixed cursor-pointer text-primaryPink top-4 right-4" icon={faXmark}></FontAwesomeIcon>
      </Link>
        <div className={`my-auto w-11/12 md:w-2/3 lg:w-5/12 bg-lightGreen mx-auto px-10 py-6 text-center rounded font-playfair`}>
            <div className="primary text-primaryPink text-center font-antiqua mx-auto font-bold">
            Login
            </div>
            <form onSubmit={(e) => {
              e.preventDefault()
              handleSubmit()
            }} className='text-center text-primaryPink w-full flex flex-col items-center'>
                <label htmlFor="" className="text-lg">Username or Email:</label>
                <input autoComplete='on' required onChange={e => setUsernameOrEmail(e.target.value)} value={usernameOrEmail} type="text" className='pb-0.5 border-b-2 border-primaryPink bg-inherit outline-none w-2/3 lg:w-1/2' />
                <label htmlFor="" className="text-lg">Password:</label>
                <input autoComplete='on' required onChange={e => setPassword(e.target.value)} value={password} type="password" className='pb-0.5 border-b-2 border-primaryPink bg-inherit outline-none w-2/3 lg:w-1/2' />
                  <button disabled={submitDisabled} type='submit' className='px-4 flex py-2 text-white disabled:bg-primaryPink bg-pink-300 hover:bg-pink-400 transtion duration-300 ease-in-out rounded mt-2'>
                  {!loading ? "Submit" : <>
                      <div className='text-white mr-2 flex my-auto w-4 h-4'>
                          <Spinner></Spinner>
                      </div>
                      Loading...
                      </>}
                  </button>
            </form>
            <Link href={"/auth/signup"} onClick={() => setShowingModal(false)} className="text-grayPink flex mx-auto w-min min-w-max font-sans cursor-pointer hover:text-primaryPink duration-300 ease-in-out transition font-bold">
                Signup
              </Link>
            <button disabled={forgotDisabled} onClick={() => {
              setShowingModal(true)
              setForgotDisabled(true)
              setForgotLoading(true)
            }}>
              <div className="mt-2 text-primaryPink flex mx-auto w-min min-w-max font-sans cursor-pointer hover:scale-105 border-primaryPink border-b-0 hover:border-b-2 duration-300 ease-in-out transition font-bold">
              {!forgotLoading ? "Forgot Password?" : <div className='text-primaryPink flex'>
                    <div className='text-primaryPink mr-2 flex my-auto w-4 h-4'>
                        <Spinner></Spinner>
                    </div>
                    Loading...
                    </div>}
              </div>
            </button>
            <div>
              <div className="flex mt-8 flex-col">
                <div className="secondary font-bold text-primaryPink underline decoration-2 decoration-unsaturatedPink">
                  Login with:
                </div>
                <div className="space-x-2 flex">
                  <button className='mt-4 mx-auto' onClick={googleLogin}>
                    <Image src="/google.png" className="w-7 h-7 md:w-8 md:h-8 hover:scale-110 transition-all duration-300 ease-in-out" height={75} width={75} />
                    {/* <div className='ml-2 small text-gray-400 font-semibold'>
                      Sign in with Google
                    </div> */}
                  </button>
                </div>
              </div>
            </div>
            
        </div>

        {
          showingModal ?
          <div className="fixed w-full left-0 top-0 h-full bg-black/30">
          <form onSubmit={(e) => {
            e.preventDefault()
            forgotPassword()
          }} className='bg-lightEarth text-primaryPink flex flex-col px-4 py-4 w-5/6 sm:w-2/3 lg:w-1/3  text-center rounded mt-48 mx-auto' action="">
            <p className="secondary font-bold">
              Email:
            </p>
            <label htmlFor="" className="text-lg">Username or Email:</label>
            <input required onChange={e => setForgotEmail(e.target.value)} value={forgotEmail} type="email" className='mx-auto border-b-2 text-center bg-inherit outline-none w-1/2 border-primaryPink' />
            <div className="flex w-min min-w-max gap-2 mx-auto">
              <button className='bg-pink-300 hover:bg-pink-400 duration-300 ease-in-out transition text-white px-2 py-1 mx-auto w-min rounded mt-4' type="submit">
              {!loadingReset ? "Submit" : <div className='text-white flex'>
                      <div className='text-white mr-2 flex my-auto w-4 h-4'>
                          <Spinner></Spinner>
                      </div>
                      Sending...
                      </div>}
              </button>
              <button onClick={() => {
                setShowingModal(false)
                setForgotDisabled(false)
                setForgotLoading(false)
              }} className='bg-red-400 hover:bg-red-500 duration-300 ease-in-out transition text-white px-2 py-1 mx-auto w-min rounded mt-4' type="submit">
                Close
              </button>
            </div>
          </form>
          </div>
          : 
          <>
          </>
        }
    </div>
  )
}