import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import Link from "next/link"
import { faXmark } from "@fortawesome/free-solid-svg-icons"

export default function Page() {
    return (
        <div className='flex text-center flex-col'>
          <div className="w-screen -z-10 h-screen fixed bg-lightEarth">

          </div>
          <Link href={"/"}>
            <FontAwesomeIcon className="w-8 h-8 hover:text-unsaturatedPink duration-300 transition ease-in-out fixed cursor-pointer text-primaryPink top-4 right-4" icon={faXmark}></FontAwesomeIcon>
          </Link>
          <div className="primaryPink pb-8 mt-20 text-center w-min underline decoration-8 pb-2 decoration-grayPink min-w-max mx-auto text-primaryPink primary font-questrial font-bold">
            Terms and Conditions
          </div>
          <div className="flex flex-col space-y-4 mt-6">
            {/* 1 */}
            <div className="flex flex-col"> 
              <p className="secondary font-bold text-primaryPink">
                1. Introduction and Preamble
              </p>
              <p className="font-semibold semi text-unsturatedPink small w-1/2 mx-auto text-center text-grayPink">

              Welcome to DoulAI, a groundbreaking digital health platform designed to provide you with a transformative experience in maternity care through the sophisticated application of advanced artificial intelligence technology. The choice to utilize the diverse range of innovative services we offer signifies your unambiguous agreement to comply with the Terms and Conditions (T&Cs) that we have set forth with utmost care and meticulous detail. These T&Cs establish a legally binding contract between you – the user – and DoulAI, the provider of these avant-garde digital health services. The significance of this contract necessitates your full attention and conscientious understanding of its content. It is paramount that you thoroughly read, comprehend, and accept these terms before deciding to use our services.
<br /><br />
The purpose of these T&Cs is manifold. Primarily, they define the scope and limitations of our services, establish our rights and obligations, and clarify your responsibilities and privileges as a user of our platform. Moreover, they provide a detailed outline of what you may expect from our services and what we, in turn, anticipate from you. They describe the mechanism for the resolution of potential disputes and offer guidelines on how to navigate possible issues that may arise during your use of our services. In essence, these T&Cs aim to offer a comprehensive framework that governs our relationship with you.
<br /><br />
The decision to employ our services comes with the expectation that you have duly perused these terms and have granted your informed consent to comply with all its provisions. Your agreement to these terms manifests your understanding of your rights, responsibilities, and restrictions under this contract and acknowledges your commitment to uphold the same. If, however, you find any term, condition, or provision unacceptable, it is your responsibility to promptly discontinue the use of our services.
<br /><br />
In a broader context, DoulAI operates under the guiding principles of transparency, equity, and respect for user autonomy. We view this contract as an embodiment of those principles, aiming to ensure fair and balanced interactions between you and DoulAI. These T&Cs provide a blueprint for maintaining the integrity of our platform, the dignity of our users, and the quality of the services we provide. They ensure that the standards we uphold remain consistent and uncompromised and that your rights are always protected and respected.
<br /><br />
The digital realm we navigate is both exciting and complex, teeming with possibilities and challenges alike. As such, these T&Cs also recognize the dynamic nature of our platform and the need for flexibility in the face of constant technological innovation. Therefore, we retain the right to modify, amend, or update these terms as and when required, to ensure that they reflect the most current industry practices and meet the evolving needs of our users.
<br /><br />
These T&Cs are intended to be as comprehensive and understandable as possible. They aim to strike a balance between legal precision and user-friendliness. To assist you, they are written in a structured manner, divided into several sections, each addressing a specific topic related to the use of our services. We encourage you to take the time to understand each section and how they collectively form the agreement between you and DoulAI.
<br /><br />
In the spirit of full disclosure, we also provide you with the necessary information on how to contact us should you require any clarification or further explanation of any of the terms, conditions, or provisions outlined herein. We consider open communication with our users as a cornerstone of our operations, and we are committed to ensuring you are fully informed about your engagement with our platform.
<br /><br />
Your use of our services not only signifies your acceptance of these T&Cs but also your trust in DoulAI. We understand that trust is a precious commodity, especially when it comes to maternity care. Hence, we consider this agreement as more than just a contract. It is a partnership, one that we hope will contribute to making your journey toward parenthood as smooth, supportive, and empowering as possible.
<br /><br />
To conclude this introduction, we would like to reiterate the necessity of understanding and agreeing to these T&Cs before commencing your use of our services. It is only by consenting to these terms that you may fully harness the transformative potential of DoulAI. However, if you disagree with any term, condition, or provision, you must immediately cease your use of our services. Please know that your safety, satisfaction, and well-being remain our top priority, and we are here to support you every step of the way.

              </p>
            </div>
            {/* 2 */}
            <div className="flex flex-col"> 
              <p className="secondary font-bold text-primaryPink">
                2. Our Services
              </p>
              <p className="font-semibold semi text-unsturatedPink small w-1/2 mx-auto text-center text-grayPink">
The principal objective of DoulAI is to provide top-tier maternity care information and support via our state-of-the-art AI technology platform. We endeavor to harmonize and assimilate the collective wisdom of a spectrum of professionals in the obstetrics and gynecology fields, and to couple this rich trove of knowledge with innovative AI algorithms. The result is a unique, insightful, and supportive digital maternity care experience designed to nurture you during this crucial life phase.
<br /> <br />
Through a meticulously designed user interface, DoulAI makes it easy for you to navigate through the sea of maternity-related information, demystifying complicated medical terminologies and providing you with the assurance you need during your maternity journey. Our AI algorithms, which have been trained on extensive and diverse datasets, are designed to provide you with consistent and reliable information, empowering you to understand and manage your pregnancy better.
<br /> <br />
However, as you engage with DoulAI, it is of paramount importance to remember that despite being a product of cutting-edge technology, DoulAI is not a substitute for professional medical advice, diagnosis, or treatment. Instead, it should be viewed as a complementary tool that aids in reinforcing your understanding of maternity care. While we aspire to be a trustworthy companion during your maternity journey, it is critical to recognize that DoulAI does not exist to replace the invaluable relationship between you and your healthcare providers.
<br /> <br />
In its role as an information provider, DoulAI generates general advice that is not tailored to individual medical needs or conditions. The insights we offer stem from a broad base of maternity care knowledge and are intended to provide a general understanding of the subject matter. These insights, while valuable, may not accurately or comprehensively address unique or specific circumstances, thus, we urge you to consult with a physician, midwife, or other qualified healthcare provider if you have any health-related concerns.
<br /> <br />
In addition to this, we implore you to be mindful that while DoulAI aims to be a reliable source of information, the dynamic nature of medical science means that new research may evolve or alter the understanding of certain aspects of maternity care. As such, while we strive to keep our content updated and in line with current research, there may be occasions where new findings have not yet been incorporated into our platform.
<br /> <br />
DoulAI{"'"}s unique algorithm-based learning design enables the platform to learn from interactions, improving its effectiveness and making the user experience more personalized over time. We use a variety of techniques, such as Natural Language Processing (NLP), machine learning, and other advanced AI technologies to deliver a unique service that stands at the intersection of technology and healthcare.
<br /> <br />
Despite our dedication to providing accurate and reliable information, the use of DoulAI does not create a doctor-patient relationship. As mentioned, our content is general and does not take into account individual health circumstances. Consequently, any decisions regarding your health should be made in consultation with your healthcare provider. We reiterate that the information provided by DoulAI should not be used for self-diagnosis or for treating health problems or diseases.
<br /> <br />
Furthermore, we aim to provide a safe and supportive environment for our users. DoulAI takes privacy very seriously and we are committed to protecting your data. Our platform has been designed with robust security measures in place to ensure the confidentiality of your information. Our commitment to privacy is detailed further in our Privacy Policy.
<br /> <br />
To optimize the benefits derived from DoulAI, we encourage users to engage actively with our platform, make use of the information provided, and incorporate it into discussions with healthcare providers. In doing so, you can deepen your understanding of maternity care, empower yourself with knowledge, and make more informed decisions about your health.
<br /> <br />
In conclusion, while DoulAI is a pioneering tool designed to enrich your understanding of maternity care, it is crucial to view it as a complement to, not a replacement for, professional medical advice. Our mission is to empower you with reliable information that can enhance your maternity journey, but ultimately, the decision-making power rests with you and your healthcare provider. By acknowledging and understanding the role and limitations of DoulAI, you can better navigate your maternity journey and make the most of this remarkable phase of life.


              </p>
            </div>
            {/* 3 */}
            <div className="flex flex-col"> 
              <p className="secondary font-bold text-primaryPink">
                3. Liability Limitations
              </p>
              <p className="font-semibold semi text-unsturatedPink small w-1/2 mx-auto text-center text-grayPink">
DoulAI, through its sophisticated artificial intelligence (AI) technology, strives to deliver an unmatched level of accuracy and reliability in disseminating maternity care information to its users. Despite the rigorous mechanisms in place and our commitment to maintaining the highest level of quality control, it is imperative to understand that due to the ever-evolving nature of medical knowledge and practices, as well as the inherent limitations of AI technology, DoulAI cannot guarantee absolute infallibility of its services and content.
<br /> <br />
The field of medicine, particularly in obstetrics and gynecology, undergoes constant updates and revisions. New research, discoveries, and updated clinical practices frequently reshape our understanding and management of different health conditions. As a digital platform, we make an earnest effort to keep up with this rapid pace of development. Nevertheless, the dynamism of this field might result in certain instances where the most recent information has not been incorporated into our platform promptly.
<br /> <br />
In light of these inherent uncertainties and the potential for information lag, DoulAI disclaims responsibility for any inaccuracies, omissions, or errors in the information provided through the platform. Our content should not be used as the sole basis for making critical medical decisions without consulting a qualified healthcare provider. DoulAI cannot be held accountable for any actions taken or not taken based on the information provided by our platform.
<br /> <br />
Moreover, it must be understood that AI, despite its advanced capabilities, is not perfect and has its limitations. It is bound by the quality and quantity of the data it has been trained on. Hence, while we have made every effort to ensure the best possible learning for our AI algorithms, they are still susceptible to potential errors and oversights.
<br /> <br />
In no event will DoulAI, its parent companies, affiliates, partners, employees, agents, or licensors be liable for any direct, indirect, incidental, consequential, special, exemplary, or punitive damages. This includes, without limitation, damages resulting from lost profits, loss of goodwill, loss of data, work stoppage, accuracy of results, or computer failure or malfunction.
<br /> <br />
This disclaimer applies even if you experience difficulties or inability to use our services due to any reason, including technical issues or downtime. It also applies even if we have been advised of the potential for such damages. It is important to understand that while DoulAI provides a platform for maternity care information, the onus of assessing the suitability, relevance, and accuracy of the information, as well as making medical decisions, ultimately lies with the user and their healthcare provider.
<br /> <br />
In using our services, you acknowledge that you understand and accept these inherent limitations. You also acknowledge that DoulAI, under no circumstances, will bear the risk of any adverse consequences that arise from your use, or inability to use, the information and services provided.
<br /> <br />
By incorporating this understanding into your engagement with DoulAI, you can make the most of the valuable insights provided, while maintaining a clear perspective on the scope and limitations of AI technology in healthcare. In conclusion, we at DoulAI aspire to be your trusted companion in your maternity journey, always striving to enhance the richness and reliability of our services while keeping you informed about the inherent limitations and disclaimers.

              </p>
            </div>
            {/* 4 */}
            <div className="flex flex-col"> 
              <p className="secondary font-bold text-primaryPink">
              4. Arbitration Agreement & Class Action Waiver
              </p>
              <p className="font-semibold semi text-unsturatedPink small w-1/2 mx-auto text-center text-grayPink">
In opting to utilize DoulAI and its suite of services, you are explicitly agreeing to settle any disputes, controversies, or claims that may arise out of your usage of our services through a process of final and binding arbitration, as opposed to pursuing a court trial. This agreement to arbitrate is intended to be interpreted as broadly as possible. It encompasses an array of potential disputes, including, but not limited to, issues relating to the use of our services, interpretation of these Terms and Conditions (T&Cs), matters about privacy, and any other matter or disagreement that might originate from your interaction with DoulAI.
<br /> <br />
By consenting to this arbitration agreement, it is paramount that you understand and acknowledge the implications of your decision. Primarily, you are relinquishing the right to litigate claims in a court or before a jury about any such claim. This agreement signals a departure from traditional court proceedings, replacing it with a streamlined, binding arbitration process.
<br /> <br />
Furthermore, you must comprehend that by accepting this arbitration agreement, you are explicitly waiving your rights to participate in any class action lawsuit or class-wide arbitration against DoulAI. This essentially means that you will not be able to join or consolidate claims with those of others or make a claim as a representative of a class of people. Instead, any dispute resolution proceedings arising out of your use of our services will be conducted solely on an individual basis and not as part of a class, consolidated, or representative action.
<br /> <br />
This individual-focused approach to dispute resolution emphasizes the importance of resolving disagreements on a case-by-case basis. It mirrors our commitment to treating each user{"'"}s concerns as unique and deserving of individual attention, ensuring that the specificity of each case is taken into account.
<br /> <br />
By assenting to these Terms and Conditions, you are affirming your understanding of, and agreement to, these dispute resolution processes. We strongly advise that you carefully consider these terms, as they have significant implications for your legal rights and remedies.
<br /> <br />
In summary, by agreeing to the outlined T&Cs and choosing to use DoulAI, you are entering into an agreement that places binding arbitration as the preferred method for dispute resolution. Simultaneously, you are waiving your rights to take part in a class action lawsuit or class-wide arbitration against DoulAI. As a user of our platform, your acceptance of these terms ensures that any potential disputes will be addressed individually and not as part of a class or representative action.

              </p>
            </div>
            {/* 5 */}
            <div className="flex flex-col"> 
              <p className="secondary font-bold text-primaryPink">
              5. Data Protection & Privacy
              </p>
              <p className="font-semibold semi text-unsturatedPink small w-1/2 mx-auto text-center text-grayPink">
At DoulAI, we firmly believe in upholding stringent standards of data protection and safeguarding user privacy. Our data handling practices are carefully designed and monitored to ensure full compliance with all relevant and applicable data protection regulations. This includes but is not limited to, compliance with the General Data Protection Regulation (GDPR) of the European Union and the California Consumer Privacy Act (CCPA) of the United States. We appreciate the trust you instill in us by sharing your data and assure you that we are wholeheartedly committed to safeguarding your privacy and ensuring the utmost respect for your personal information.
<br /> <br />
To collect, process, and store your data, we always seek your express consent. This consent-driven approach underlines our commitment to maintaining transparency with our users and promoting a culture of informed decision-making. We handle your data solely for the purposes detailed in our comprehensive Privacy Policy. This policy outlines the multiple ways in which we may use your data, all aimed at enhancing our services and your overall user experience.
<br /> <br />
These purposes primarily include providing and improving our services, responding to your inquiries or addressing your complaints, communicating with you about our services, and complying with applicable legal requirements and industry standards. By providing and continually refining our services, we seek to create an enriching, informative, and supportive platform for maternity care. Furthermore, when it comes to addressing your inquiries or complaints, we leverage your data to ensure a customized and effective response, thereby promoting a better user experience.
<br /> <br />
We also utilize your data to send you communications about our services, including updates, new features, and other relevant information. We believe that keeping you in the loop about our services is crucial to building a mutually beneficial relationship.
<br /> <br />
Lastly, DoulAI adheres strictly to legal requirements and industry standards, ensuring that your data is handled responsibly. Complying with laws and standards is a non-negotiable aspect of our operations, reinforcing our commitment to ethical, responsible, and law-abiding conduct in all aspects of data handling.
<br /> <br />
In summary, while we are committed to offering you an enriching platform for accessing maternity care information, we are equally dedicated to respecting and protecting your privacy. Through our transparent practices, your express consent, and our comprehensive Privacy Policy, we strive to foster a trustworthy environment where you can comfortably engage with our platform, assured that your data is in safe hands.

              </p>
            </div>
            {/* 6 */}
            <div className="flex flex-col"> 
              <p className="secondary font-bold text-primaryPink">
              6. User Agreement & Legal Consequences
              </p>
              <p className="font-semibold semi text-unsturatedPink small w-1/2 mx-auto text-center text-grayPink">
These Terms and Conditions (T&Cs) act as a legally binding agreement between you, as the user, and DoulAI, establishing the rules and guidelines governing your access to and use of our services. By choosing to access and use our services, you acknowledge and agree to comply with these terms, including any future amendments or revisions we may implement to improve our services or to reflect changes in the law or our business practices.
<br /> <br />
Please understand that non-compliance or failure to adhere to any part of these T&Cs may lead to serious legal consequences. The spectrum of these consequences is broad and can range from administrative measures to legal actions, as deemed appropriate in each specific case. For instance, we reserve the right to terminate your access to our services, either temporarily or permanently, if we determine that you have violated any of these terms.
<br /> <br />
Moreover, if you have contributed any content to our platform and we find it to be in breach of these T&Cs, we may remove such content at our discretion. We uphold the right to moderate, regulate, and control the content posted on our platform to ensure it aligns with our standards and legal obligations.
<br /> <br />
In more severe cases, where your violation of these T&Cs results in losses or damages to DoulAI, we may pursue legal action against you to recover those losses. Such action can include but is not limited to, seeking damages, initiating litigation, or taking other legal recourse as necessary under the applicable laws and regulations.
<br /> <br />
Finally, we retain the right to report any activities that we suspect to be illegal to the appropriate legal authorities, and we will cooperate fully with those authorities by disclosing your details to them if required.
<br /> <br />
By agreeing to these T&Cs, you are thus acknowledging and accepting that any breach may result in severe legal consequences, up to and including legal action. We strongly advise that you understand these potential consequences and act in compliance with these terms to ensure a seamless and enriching experience with our platform.
<br /> <br />
In conclusion, these T&Cs are not merely guidelines, but form a legally binding agreement between you and DoulAI. They carry significant legal implications, and your continued use of our services implies your understanding and acceptance of these terms, as well as the potential consequences for any violations.

              </p>
            </div>
            {/* 7 */}
            <div className="flex flex-col"> 
              <p className="secondary font-bold text-primaryPink">
              7. Governing Law & Jurisdiction
              </p>
              <p className="font-semibold semi text-unsturatedPink small w-1/2 mx-auto text-center text-grayPink">
These Terms and Conditions (T&Cs), as well as any disputes, controversies, or claims that may arise out of or in connection with them, or relation to your use of our services, are governed by and interpreted in accordance with the laws of the state of California, United States. This holds irrespective of conflict of laws principles, which might otherwise mandate the application of the laws of another jurisdiction. This explicit choice of law is intended to provide predictability and consistency in the interpretation and enforcement of these T&Cs.
<br /> <br />
In electing to use our services, you are knowingly and willingly consent to the personal jurisdiction of the state and federal courts located within the state of California to adjudicate and resolve any such disputes. This consent to jurisdiction means that you agree to bring any and all disputes arising out of these T&Cs or your use of our services in these courts. It also means that you waive any objection or defense you may have based on the alleged inconvenience or inappropriateness of these courts to hear such disputes.
<br /> <br />
In tandem, this consent also entails an agreement that these courts represent the appropriate venue for any such proceedings, effectively barring you from initiating proceedings related to these T&Cs or the use of our services in any other venue, jurisdiction, or forum. Thus, you are acknowledging that you will not initiate or pursue any legal actions related to these T&Cs or our services in any court other than the state and federal courts located within California.
<br /> <br />
Further, you are acknowledging and accepting that this agreement to the jurisdiction of California{"'"}s courts is made within the exclusive jurisdiction of the United States and its courts. Therefore, any legal proceedings arising out of these T&Cs or the use of our services shall be conducted in accordance with U.S. law and under the supervision of U.S. courts. This choice of jurisdiction is intended to ensure that both parties have a clear understanding of the applicable legal principles and rules of procedure, providing for a fair and orderly resolution of any disputes.
<br /> <br />
In summary, by choosing to access and use our services, you are agreeing that these T&Cs, and any disputes that may arise from them or your use of our services, are governed by the laws of the state of California, U.S. You are further consenting to the jurisdiction of the state and federal courts in California for the purpose of litigating such disputes. In doing so, you are recognizing and accepting that this agreement is made within the exclusive jurisdiction of the United States, and that any legal proceedings will be conducted in accordance with U.S. law. This provision is critical to ensuring a clear, consistent, and predictable framework for the resolution of any disputes between you and DoulAI.

              </p>
            </div>
            {/* 8 */}
            <div className="flex flex-col"> 
              <p className="secondary font-bold text-primaryPink">
              8. Updates and Amendments
              </p>
              <p className="font-semibold semi text-unsturatedPink small w-1/2 mx-auto text-center text-grayPink">
DoulAI expressly reserves the right, at our sole discretion, to update, revise, modify, or otherwise alter these Terms and Conditions (T&Cs) at any given point in time. We may undertake such revisions to ensure that our T&Cs remain up-to-date and compliant with the relevant laws and regulations, reflect changes in our services or business practices, or for any other reason that we deem necessary.
<br /> <br />
Upon making any such changes to these T&Cs, we will promptly communicate the updated terms through various channels. These may include, but are not limited to, posting the revised T&Cs on our platform, directly notifying you via email or other communication methods we have established with you, or providing a conspicuous notice of the changes on our platform. This ensures that you are kept fully informed about any modifications to our T&Cs and can continue using our services with a clear understanding of the governing terms.
<br /> <br />
It is crucial to understand that these changes to the T&Cs will become effective immediately upon their posting on our platform or through other communication methods. From the moment these updated T&Cs are communicated to you, they supersede and replace all previous versions of the T&Cs, governing your use of our services henceforth.
<br /> <br />
Your continued use of DoulAI{"'"}s services following the posting of changes to these T&Cs is deemed as your full acceptance and agreement to abide by the updated T&Cs. By continuing to use our services after changes have been made to the T&Cs, you are actively demonstrating your acceptance of those changes. This continued use acts as an affirmation of your commitment to abide by the revised terms, and your recognition of them as the prevailing agreement between you and DoulAI.
<br /> <br />
If, however, you find yourself in disagreement with the revised T&Cs, you are required to cease using our services immediately. Continued use of our services after being informed of changes to the T&Cs, despite not agreeing with them, would be considered a breach of these terms.
<br /> <br />
In conclusion, by accepting these terms, you are unequivocally confirming your understanding of, agreement to, and acceptance of all the terms and conditions contained herein. Moreover, you are affirming the declarations made in these terms and expressing your acceptance of the provisions of this contract. You also acknowledge that these T&Cs may be updated from time to time and agree to regularly review these terms to ensure your continued acceptance and compliance. This commitment to staying informed of our T&Cs and adhering to their updated versions is crucial for maintaining a positive, mutually beneficial relationship with DoulAI.


              </p>
            </div>
          </div>
        </div>
    )
}