import Navbar from "@/components/Navbar";
import { withIronSessionSsr } from "iron-session/next";
import { ironOptions } from "@/utils/ironConfig";
import { checkForUser, connectMongo, getGptHistory, getUserAiSession, getUserAiSessions, setAiSession, setAiSessions } from "@/utils/api";
import { useEffect, useRef, useState } from "react";
import {
  ages,
  countries,
  educationLevels,
  incomeBrackets,
  pregnancyStatuses,
  raceEthnicities,
  subscriptions,
} from "@/utils/standards";
import { useRouter } from "next/router";
import { faSpinner, faXmark } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Image from "next/image";

import Aos from "aos";
import 'aos/dist/aos.css';
import Spinner from "@/components/Spinner";
import Link from "next/link";
import obtainSessionUser from "@/utils/obtainSessionUser";


export const getServerSideProps = withIronSessionSsr(async function ({
  req,
  res,
}) {
  await connectMongo();
  let user = null;
  // if(user) {
  //   delete user.key
  //   delete user.salt
  //   console.log("User: ", user)
  //   console.log("Key: " + user.keys)
  //   req.session.user = user
  //   await req.session.save()
  // }
  console.log("Session User in Profile View: ", req.session.user);
  console.log(`Undefined ${req.session.user === undefined}`)
  if(!req.session.user?.verified) {
    return {
      redirect: {
        destination: '/?reasonKicked=You can\'t access your profile until you verify your email',
        permanent: true,
      },
    }
  }
  if(!req.session.user || req.session.user === undefined || !req.session.user.verified) {
    return {
      redirect: {
        destination: '/',
        permanent: true,
      },
    }
  } 
  

  if(req.session.user) {
    const user = await checkForUser(req.session.user.username)
    console.log("User from MongoDb at index: ", user)
    // if(user) {
    //   delete user.key
    //   delete user.salt
    //   console.log("User: ", user)
    //   console.log("Key: " + user.keys)
    //   req.session.user = user
    //   await req.session.save()
    // }
    if(user) {
      req.session.user = obtainSessionUser(user)
      await req.session.save()
    }
  }

  console.log("Session User: ", req.session.user)
  return { props: { user: JSON.parse(JSON.stringify(req.session.user)) ?? null } };
},
ironOptions);

// export const getServerSideProps = withIronSessionSsr(async function ({
//   req,
//   res,
// }) {
//   await connectMongo()

//   if(!req.session.user || req.session.user === undefined || !req.session.user.verified) {
//     return {
//       redirect: {
//         destination: '/',
//         permanent: true,
//       },
//     }
//   } 
  
//   let hasSession = await getUserAiSession(req.session.user.user_id)
//   console.log("GPT Session? ", hasSession)

//   if(hasSession) {
//     return { props: { issue: 0 }}  
//   }

//   await setAiSession(req.session.user.user_id, true)

//   await connectMongo();
//   let user = await checkForUser(req.session.user.username);
//   console.log("Session User in Chatbot: ", user)
//   let gptHistory = await getGptHistory(user._id)

//   // console.log("Session User: ", req.session.user);
//   return { props: { openSession: hasSession, gptHistory: JSON.parse(JSON.stringify(gptHistory)), user: req.session.user ?? null } };
// },
// ironOptions);

export default function Page({ user }) {
  const router = useRouter()

  const [query, setQuery] = useState("")
  const [loading, setLoading] = useState(false)
  const [queriesAndResponses, setQueriesAndResponses] = useState([])
  const [isOpen, setIsOpen] = useState(true)
  const [loadingPast, setLoadingPast] = useState(false)
  const [errorMessage, setErrorMessage] = useState("Loading...")
  const [paidMember, setPaidMember] = useState(user.subscription == 1 || user.subscription == 2)
  const [questions, setQuestions] = useState(0)
  const [initialLoad, setInitialLoad] = useState(true)

  const timeoutRef = useRef()
  const queriesAndResponsesRef = useRef()

  

  useEffect(()=>{
    let setRouterEvent = false
    const checkSessions = async (times) => {
      const WAIT_TIME = 500
      let open = await fetch("/api/sessions").then(res => res.json())
      open = open.openSession
      console.log("Previous is Open: ", open)
      

    if(open) {
      if(times >= 3) {
        setErrorMessage("You can only have the chatbot open in one window at a time")
        setTimeout(() => {
          router.push("/")
        }, 1500)
      } else {
        console.log("Time: ", times)
        setTimeout(() => {
          checkSessions(times+1)
        }, WAIT_TIME)
      }
    } else {
      setLoadingPast(true)
      let count = questions
      console.log("No others")
      setErrorMessage(null)
      console.log("User: ", user)
      let gptHistory = await fetch("/api/chatbot/history").then(res => res.json())
      gptHistory = gptHistory.gptHistory
      console.log("History: ", gptHistory)
      if(gptHistory) {
        setQueriesAndResponses([])
        queriesAndResponsesRef.current = []
          console.log("History: ", gptHistory)
          let sectionContent = gptHistory.sections[0].content
          // let reversed = []
          console.log("Section Content Length: " + sectionContent.length)
          for(let i = 0; i < sectionContent.length; i++) {
            console.log("Content: ", sectionContent[i])
            if(sectionContent[i].role == "user") {
              console.log("Adding")
              count++
              console.log("Count Now: ", count)
            }
            // reversed[i] = sectionContent[sectionContent.length - 1 - i]
          }
          console.log("History Section: ", sectionContent)
          setQueriesAndResponses(sectionContent)
          queriesAndResponsesRef.current = sectionContent
          console.log("\n\nCount Final:", count)
          setQuestions(count)
      }
      setLoadingPast(false)
      let stat = await fetch("/api/sessions", {
        method: "POST",
        headers: {
          "Content-Type" : "application/json"
        },
        body: JSON.stringify({
          status: true
        })
      }).then(res => res.json())
      console.log("Stat Success: ", stat.success)
      setQuestions(count)
      setInitialLoad(false)
      if(!stat.success) {
        setErrorMessage("Something went wrong, try again soon")
        setTimeout(() => {
          router.push("/")
        }, 1500)
      }
    }
    // console.log("Session Open? ", openSession)
    }

    const leaveFunc = async (e) => {
      let gptHistory = queriesAndResponsesRef.current
      console.log("Stuff: ", gptHistory)
      await fetch("/api/sessions", {
        method: "POST",
        headers: {
          "Content-Type" : "application/json"
        },
        body: JSON.stringify({
          status: false,
          gptHistory
        })
      })
    }
    
    const leaveBrowserFunc = async (e) => {
      e.preventDefault()
      e.returnValue = ""
      let gptHistory = queriesAndResponsesRef.current
      console.log("Stuff: ", gptHistory)
      await fetch("/api/sessions", {
        method: "POST",
        headers: {
          "Content-Type" : "application/json"
        },
        body: JSON.stringify({
          status: false,
          gptHistory
        })
      })
    }
      
      window.onbeforeunload = leaveBrowserFunc
  
      router.events.on("routeChangeStart", leaveFunc)
      setRouterEvent = true
  
      Aos.init()

    timeoutRef.current = setTimeout(() => {
      checkSessions(0)
    }, 2000)

    return () => {
      if(typeof leaveFunc != "undefined" && leaveFunc) router.events.off('routeChangeStart', leaveFunc);
      if(typeof leaveBrowserFunc != "undefined" && leaveBrowserFunc) window.removeEventListener("beforeunload", leaveBrowserFunc)
    }
  }, [])

  const submitQuery = async () => {
    let foundResult = false
    setQuery("")
    console.log("Query: ", query)
    let additions = []
    additions.unshift({content: query, role: "user"})
    setLoading(true)
    let timeout = setTimeout(() => {
      console.log(`Found: ${foundResult}`)
      if(!foundResult) {
        alert("Small error with chatbot, ask again or come back later")
        setLoading(false)
      }
    }, 30000 * 1)
    console.log("Queries etc...", queriesAndResponses)
    let data = await fetch('/api/chatbot', {
        method: "POST",
        headers: {
            "Content-Type" : "application/json"
        },
        body: JSON.stringify({
            query,
            gptHistory: queriesAndResponses
        })
    }).then(res => {
      return res.json()
    })
    console.log(data)
    foundResult = data.success
    if(foundResult) {
      setLoading(false)
      let response = data.response
      additions.unshift({content: response, role: "assistant"})
      setQuestions(questions + 1)
      setQueriesAndResponses([...additions, ...queriesAndResponses])
      queriesAndResponsesRef.current = [...additions, ...queriesAndResponses]
    } else if(!foundResult) {
      clearTimeout(timeout)
      alert("Small error with chatbot, ask again or come back later")
      setLoading(false)
    }
  }

  console.log("User: ", user);

  return (
    <div className="h-screen !bg-lightEarth justify-center items-center px-4 flex">
    <Link href={"/"}>
      <FontAwesomeIcon className="w-8 h-8 hover:text-unsaturatedPink duration-300 transition ease-in-out fixed cursor-pointer text-primaryPink top-4 right-4" icon={faXmark}></FontAwesomeIcon>
    </Link>
    {
      errorMessage ?
      <div className="px-4 flex text-xl py-2 font-semibold bg-white text-primaryPink w-min min-w-max mx-auto rounded">
        <div className="text-grayPink mr-4 w-8 h-8 my-auto">
          <Spinner></Spinner>
        </div> {errorMessage}
      </div> : 
    <div>
      <div className="text-center mt-24 mx-auto w-5/6 sm:w-min min-w-max text-primaryPink sm:mt-4">
        <div className="semi font-rozhaOne">DoulAi</div>
        <div className="secondary font-semibold mx-auto text-grayPink">
          Your comprehensive guide to a healthy pregnancy <br />
          Subscription: <span className="text-primaryPink">{subscriptions[user.subscription].title}</span>
        </div>
        {
          !paidMember ? 
          <div className="small font-semibold mx-auto text-grayPink">
            *As a member on trial you are limited to 5 messages <br/>
            Question Count: {questions}
          </div> : <></>
        }
        {
          queriesAndResponses.length > 0 ? 
          <div className="flex py-6 w-72 sm:w-[400px] md:w-[500px] lg:w-[750px] mt-12 sm:mt-4 flex-col-reverse h-[400px] masked-overflow overflow-y-auto px-3 space-y-8 mx-auto break-words">
            {/* Newest additions are first and we want them to appear at the bottom, hence the flex-col-reverse, */}
            {queriesAndResponses.map((obj, i) => (
              <>
                {
                  obj.role != "system" ?
                  <div key={`boxInstance${i}`} className="relative hover:-translate-y-2 transition ease-in-out duration-300">
                      {
                        obj.role == "assistant" ? 
                        <div className="absolute top-2 -left-2 z-10 flex">
                          <Image alt="femaleDoctor" src="/femaleDoctor.jpg" width={40} height={40} className="w-10 h-10 rounded-full" />
                          <span className="my-auto ml-2 font-semibold text-white bg-black/25 px-2 rounded">Dr. Folabi</span>
                        </div>
                        : <></>
                      }
                    <div key={`textbox${i}`} className={`p-6 mt-6 text-start h-max max-h-max text-sm w-2/3 break-words rounded ${obj.role == "user" ? " ml-auto text-white bg-primaryPink" : " mr-auto bg-white text-primaryPink font-semibold"}`}>
                      {obj.content}
                    </div>
                  </div>
                  : 
                  <></>
                }
              </>
          ))}
          </div>
          : <></>
        }
        {
          loadingPast ? 
          <>
          <div className="my-24 flex flex-col space-y-10 w-min min-w-max mx-auto">
            <FontAwesomeIcon className={`animate-spin w-8 h-8 mx-auto text-grayPink`} icon={faSpinner}></FontAwesomeIcon>
            <p className="semi text-primaryPink animate-bounce font-sacramento text-center">Loading Past Messages...</p>
          </div>
          </>
          :
          <>
          {
            queriesAndResponses.length == 0 ? <>
            <p className="text-xl text-grayPink my-24">
              Start your conversation now...
            </p>
            </>: <></>
          }
          </>
        }
        {
          !initialLoad ?
          <>
          {
            !(questions >= 5 && !paidMember) ?
            <div className="text-center py-2 w-full bg-blend-saturation">
              <div className="w-min min-w-max mx-auto mb-4">
                <p className="text-4xl font-rozhaOne text-primaryPink">
                    Ask anything:
                </p>
                <form onSubmit={e => {
                    if(!loading) {
                        e.preventDefault()
                        submitQuery()
                    }
                }} action="" className="space-y-4">
                    <input min={1} onChange={e=>setQuery(e.target.value)} value={query} type="text" className="w-3/4 px-2 py-1 text-primaryPink mx-auto appearance-none outline-none border-primaryPink bg-transparent border-b-2" />
                    <button disabled={loading} type="submit" className={`px-2 ${!loading ? "text-white" : "text-primaryPink"} flex justify-center disabled:bg-transparent w-1/2 mx-auto py-1 bg-primaryPink hover:bg-rose-400 transition duration-300 ease-in-out rounded`}>
                        <FontAwesomeIcon className={`${loading ? "animate-spin" : "hidden"} mr-2 w-3 h-3 my-auto`} icon={faSpinner}></FontAwesomeIcon>
                        {loading ? "Thinking..." : "Send"}
                    </button>
                </form>
              </div>
            </div> : <p className="secondary text-primaryPink">{"You've"} run out of free messages</p>
          }</> : <></>
        }
      </div>
    </div>
    }
    </div>
  );
}
