// import { useRouter } from "next/router";
import { withIronSessionSsr } from "iron-session/next";
import { ironOptions } from "@/utils/ironConfig";
import { checkForUser, connectMongo, deleteTokenFor, findToken, updateUser } from "@/utils/api";
import obtainSessionUser from "@/utils/obtainSessionUser";
import { useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { useRouter } from "next/router";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSpinner } from "@fortawesome/free-solid-svg-icons";

export const getServerSideProps = withIronSessionSsr(async function ({
    req,
    res,
  }) {
    const urlParts = req.url.split("/")
    console.log(urlParts)
    const id = urlParts[2]

    return { props: {id: id}};
  },
  ironOptions);
  
  export default function Page({id}) {
    const router = useRouter()

    useEffect(()=>{
      async function verify() {
        console.log("Id: ", id)
        let data = await fetch("/api/verify/" + id).then(res => res.json())
        console.log("Date: ", data)
        if(data.success) {
          router.push("/?reload=true")
        } else {
          alert("Sorry this may be a wrong or expired code")
          router.push("/")
        }
      }
      verify()
    }, [])

    // await verify(router.query.id)

    // const verify = async(id) => {
    //     let data = await fetch("/api/verify", {
    //         method: "POST",
    //         headers: {
    //             "Content-Type":"application/json"
    //         },
    //         body: JSON.stringify({
    //             id
    //         })
    //     })
    //     if(data.success) {
    //         router.push("/")
    //     } else {
    //         if(typeof window !== "undefined") {
    //             alert("Sorry we weren't able to verify your account, either your verification link expired or this is the wrong one")
    //         }
    //         router.push("/")
    //     }
    // }
    

    return (
        <>
          <div className="mt-16 flex flex-col space-y-10 w-min min-w-max mx-auto">
                <FontAwesomeIcon className={`animate-spin w-12 h-12 mx-auto text-unsaturatedPink`} icon={faSpinner}></FontAwesomeIcon>
                <p className="text-xl md:text-3xl text-primaryPink animate-bounce font-sacramento text-center">Checking for Verification Code...</p>
            </div>
        </>
    )
}