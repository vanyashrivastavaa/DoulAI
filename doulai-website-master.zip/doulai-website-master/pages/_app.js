import '@/styles/globals.css'
import { GoogleOAuthProvider } from '@react-oauth/google'
import { Inter } from 'next/font/google'
import { useRouter } from 'next/router'
import { useEffect, useRef } from 'react'

const inter = Inter({ subsets: ['latin'] })

export default function App({ Component, pageProps }) {
  let intervalRef = useRef()
  const router = useRouter()

  const update = async () => {
    console.log("Fetching")
    let data = await fetch("/api/updates").then(res => res.json())
    console.log(data)
    // router.reload()
  }

  useEffect(()=> {
    update()
    intervalRef.current = setInterval(update, 30000)
    return () => clearInterval(intervalRef.current)
  }, [])

  return (
    <>
      <GoogleOAuthProvider clientId={`827758096364-76r62ueo1633054u4ur1dkf5nva7li1s.apps.googleusercontent.com`}>
        <Component {...pageProps} />
      </GoogleOAuthProvider>
    </>
  )
}
