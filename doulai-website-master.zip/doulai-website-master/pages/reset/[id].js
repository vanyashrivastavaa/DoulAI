// import { useRouter } from "next/router";
import { withIronSessionSsr } from "iron-session/next";
import { ironOptions } from "@/utils/ironConfig";
import { checkForUser, connectMongo, deleteTokenFor, findToken, updateUser } from "@/utils/api";
import obtainSessionUser from "@/utils/obtainSessionUser";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { useRouter } from "next/router";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSpinner, faXmark } from "@fortawesome/free-solid-svg-icons";
import Spinner from "@/components/Spinner";
import Link from 'next/link'

export const getServerSideProps = withIronSessionSsr(async function ({
    req,
    res,
  }) {
    const urlParts = req.url.split("/")
    console.log(urlParts)
    const id = urlParts[2]

    return { props: {id: id}};
  },
  ironOptions);
  
  export default function Page({id}) {
    const router = useRouter()
    const [isLoading, setIsLoading] = useState(true)
    const [submitDisabled, setSubmitDisabled] = useState(false)
    const [loading, setLoading] = useState(false)
    const [confirmed, setConfirmed] = useState("")
    const [password, setPassword] = useState("")
    const [match, setMatch] = useState(false)
    const [user, setUser] = useState({})

    useEffect(()=>{
      console.log("Loading Status: ", isLoading)
      async function verify() {
        console.log("Id: ", id)
        let data = await fetch("/api/reset/" + id).then(res => res.json())
        console.log("Date: ",)
        if(data.success) {
          setUser(data.user)
          // setTimeout(()=>{
          setIsLoading(false)
          // }, 5000)
        } else {
            alert("Sorry this may be a wrong or expired code")
            router.push("/")
        }
        console.log("Loading Status: ", isLoading)
      }
      verify()
    }, [])

    const handleSubmit = async () => {
        setSubmitDisabled(true)
        setLoading(true)

        console.log("Id that we send: ", id)
        let data = await fetch("/api/forgotPassword", {
            method: "POST",
            headers: {
                "Content-Type" : "application/json"
            },
            body: JSON.stringify({
                link: id,
                password: password.replace(" ", "")
            })
        }).then(res => res.json())
        
        if(data.success) {
            alert("Successfully reset password! Sending you back to login!")
            router.push("/auth/login")
        } else {
            alert("Sorry this may be a wrong or expired code")
            router.push("/")
        }

        setSubmitDisabled(false)
        setLoading(false)
    }

    return (
        <>
        <Link href={"/"}>
          <FontAwesomeIcon className="w-8 h-8 hover:text-unsaturatedPink duration-300 transition ease-in-out fixed cursor-pointer text-primaryPink top-4 right-4" icon={faXmark}></FontAwesomeIcon>
        </Link>
        {
            isLoading ? 
            <div className="mt-16 flex flex-col space-y-10 w-min min-w-max mx-auto">
                <FontAwesomeIcon className={`animate-spin w-12 h-12 mx-auto text-unsaturatedPink`} icon={faSpinner}></FontAwesomeIcon>
                <p className="text-xl md:text-3xl text-primaryPink animate-bounce font-sacramento text-center">Checking for Reset Code...</p>
            </div> : 
            <>
            <div
              className={`text-4xl mt-48 font-bold mx-auto text-primaryPink text-center`}
            >
              <span className="text-3xl font-semibold text-grayPink">Hey</span>{" "}
              {user.username}
            </div>
              <div className={`text-xl font-bold mx-auto text-primaryPink mt-2 text-center`}>
                <span className="text-grayPink font-semibold">Email: </span>{user.email}
              </div>
            <div className={`mt-2 w-11/12 md:w-5/12 mx-auto text-primaryPink px-10 py-6 text-center rounded font-playfair`}>
            <div className="secondary xl:text-2xl mx-auto font-bold">
            Reset Your Password
            </div>
            <form onSubmit={(e) => {
              e.preventDefault()
              handleSubmit()
            }} className='text-center secondary w-full flex flex-col items-center'>
                <label htmlFor="" className="text-lg">Password:</label>
                <input required onChange={e => setPassword(e.target.value)} value={password} type="password" className='pb-0.5 border-b-2 border-primaryPink bg-inherit outline-none w-1/2' />
                <label htmlFor="" className="text-lg">Confirm Password:</label>
                <input required onChange={e => setConfirmed(e.target.value)} value={confirmed} type="password" className='pb-0.5 border-b-2 border-primaryPink bg-inherit outline-none w-1/2' />
                {
                    confirmed.length > 0 && password.length > 0 ?
                    <>
                                        <p className={`text-sm mt-2 font-semibold font-sans ${confirmed == password ? "text-green-400" : "text-rose-400"}`}>{confirmed == password ? "Passwords Match ✓" : "Passwords Don't Match"}</p>
                                        <p className={`text-sm mt-2 font-semibold font-sans ${confirmed.length >= 6 && password.length >= 6 ? "text-green-400" : "text-rose-400"}`}>{confirmed.length >= 6 && password.length >= 6 ? "" : "Passwords must be more than 6 characters"}</p>
                    </>
                    : <></>
                }
                <button disabled={submitDisabled || !(confirmed == password) || !(confirmed.length >= 6 && password.length >= 6)} type='submit' className='px-4 flex py-2 text-white disabled:bg-primaryPink bg-pink-300 hover:bg-pink-400 transtion duration-300 ease-in-out rounded mt-2'>
                {!loading ? "Submit" : <>
                    <div className='text-white mr-2 flex my-auto w-4 h-4'>
                        <Spinner></Spinner>
                    </div>
                    Loading...
                    </>}
                </button>
            </form>
        </div>
            </>
        }
        </>
    )
}