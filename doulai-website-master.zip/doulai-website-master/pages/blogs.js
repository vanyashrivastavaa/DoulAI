// import { useRouter } from "next/router";
import { withIronSessionSsr } from "iron-session/next";
import { ironOptions } from "@/utils/ironConfig";
import {
  checkForUser,
  connectMongo,
  deleteTokenFor,
  findToken,
  updateUser,
} from "@/utils/api";
import obtainSessionUser from "@/utils/obtainSessionUser";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { useRouter } from "next/router";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faGear, faSpinner, faWrench, faXmark } from "@fortawesome/free-solid-svg-icons";
import Spinner from "@/components/Spinner";
import Link from "next/link";
import ComingSoon from "@/components/ComingSoon";

export const getServerSideProps = withIronSessionSsr(async function ({
  req,
  res,
}) {
  await connectMongo();
  let user = null;
  // if(user) {
  //   delete user.key
  //   delete user.salt
  //   console.log("User: ", user)
  //   console.log("Key: " + user.keys)
  //   req.session.user = user
  //   await req.session.save()
  // }
  console.log("Session User in Profile View: ", req.session.user);
  console.log(`Undefined ${req.session.user === undefined}`);
  if (!req.session.user?.verified) {
    return {
      redirect: {
        destination:
          "/?reasonKicked=You can't access your profile until you verify your email",
        permanent: true,
      },
    };
  }
  if (
    !req.session.user ||
    req.session.user === undefined ||
    !req.session.user.verified
  ) {
    return {
      redirect: {
        destination: "/",
        permanent: true,
      },
    };
  }
  return { props: { user: req.session.user ?? null } };
},
ironOptions);

export default function Page() {
  return (
    <ComingSoon message={"Amassing blogs..."} />
  );
}
