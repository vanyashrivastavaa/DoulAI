import Crypto from "crypto"

export default function generateRandomId() {
  var min = 100000000000; // Minimum 12-digit number
  var max = 999999999999; // Maximum 12-digit number
  var randomId = Math.floor(Math.random() * (max - min + 1)) + min;
  return randomId.toString();
}

export function generateRandomToken(size = 12) {
  var min = 100000000000; // Minimum 12-digit number
  var max = 999999999999; // Maximum 12-digit number
  var randomId = Math.floor(Math.random() * (max - min + 1)) + min;
  return randomId.toString();
}