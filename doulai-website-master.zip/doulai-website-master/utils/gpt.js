import { Configuration, OpenAIApi } from "openai";

const configuration = new Configuration({
    apiKey: process.env.OPEN_AI_KEY
})

const openai = new OpenAIApi(configuration)

export class OpenaiBot {
    
    constructor() {
        const configuration = new Configuration({
            apiKey: process.env.OPEN_AI_KEY
        })

        this.openai = new OpenAIApi(configuration)
        this.messages = [{"role": "system", "content": `You are a intelligent assistant who is extremely experienced in the 
        pregnancy / maternal field. You are able to accurately answer any questions given to you, and can correctly use 
        pregnancy trimester and calendar data given to you to give users (mothers) context-aware replies. Also, 
        you can speak in multiple languages if necessary. You are also able to give accurate pregnancy health-related 
        to-do lists if a user (mother) asks. You are named DoulAi.`}]
    }

    setMessages(messages) {
        this.messages = messages
    }
    
    async question(query) {
        let chat
        if (query) {
            this.messages.push(
                {"role": "user", "content": query},
            )
            chat = await openai.createChatCompletion({
                model: "gpt-3.5-turbo", messages: this.messages
            })
        }
        console.log("Chat: ", chat.data.choices)
        let reply = chat.data.choices[0].message.content
        this.messages.push({"role": "assistant", "content": reply})
        return reply
    }
}

export const openAiBot = new OpenaiBot()