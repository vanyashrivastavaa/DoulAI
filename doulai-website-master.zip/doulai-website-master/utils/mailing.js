import nodemailer from "nodemailer"

export const sendEmail = async (email, subject, html) => {
  console.log("Sending email")
  console.log(`Email: ${process.env.EMAIL_USERNAME}, Password: ${process.env.EMAIL_PASSWORD}`)
  console.log(`Sending to ${email}`)
    try {
      const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: {
          user: `${process.env.EMAIL_USERNAME}`,
          pass: `${process.env.EMAIL_PASSWORD}`,
        },
      });
  
      await transporter.sendMail({
        from: `DoulAi Team <${process.env.EMAIL_USERNAME}>`,
        to: email,
        subject: subject,
        html: html,
      });
      console.log("email sent sucessfully");
    } catch (error) {
      console.log("email not sent");
      console.log(error);
    }
  };