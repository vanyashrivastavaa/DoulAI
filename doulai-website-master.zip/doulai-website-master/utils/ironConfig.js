export const cookieName = "doulai";
export const cookiePassword = "GerNhYoBnPvTQZpiL4hJ4JY5CZU1ZvB7";

export const ironOptions = {
  cookieName: cookieName,
  password: cookiePassword,
  // secure: true should be used in production (HTTPS) but can't be used in development (HTTP)
  cookieOptions: {
    secure: process.env.PRODUCTION == true
  },
};
