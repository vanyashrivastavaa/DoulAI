import mongoose, { mongo } from "mongoose"

const uri = process.env.MONGO_URI
import { convertHexToBuffer, deriveKeyFromPassword, encryptPassword } from '@/utils/encryptPassword';
import generateRandomId, { generateRandomToken } from "@/utils/generateRandomUserId";

let User, Token, GptHistory, ResetToken

const gptHistorySchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  sections: [
    {
      name: String,
      content: [
        {role: String, content: String}
      ]
    }
  ]
})

const userSchema = new mongoose.Schema({
  user_id: String,
  username: String,
  email: String,
  salt: String,
  key: String,
  trimester: Number,
  daysIntoTrimester: Number,
  deliveryDate: Date,
  openAiSession: {
    type: Boolean,
    default: false
  },
  todos: [
    {item: String, finished: Boolean}
  ],
  currentDay: Date,
  googleSub: Number,
  lastDayChecked: String,
  createdAt: {type: Date, default: Date.now},
  age: Number, //0-3 that corresponds with the age ranges defined in the survey,
  country: String, //Country codes will correspond to countries
  region: String,
  incomeBracket: Number, //0-4 that corresponds with the 5 income brackets
  raceEthnicity: Number, //0-4 correspond with race, 5 option means that there is a personal definition
  personalRaceDefinition: String,
  education: Number, //0-6 correspond with an educational title, 7 is a personal definition
  personalEducationDefinition: String,
  pregnancyStatus: Number, //0 is pregnant, 1 is have been pregnant, 2 is planning on pregnancy, 3 is none of the above
  verified: {type: Boolean, default: false},
  subscription: {type: Number, default: 0} //0 is free, 1 is regular, 2 is premium
})

const tokenSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  token: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expires: (60**2) //Expires after 1 hour
  }
});

const resetTokenSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  token: {
    type: String,
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
    expireAfterSeconds: (60**2) * 2 //Expires after 2 hours
  }
});

export async function connectMongo() {
  console.log("Connection State: " + mongoose.connection.readyState)
  if(mongoose.connection.readyState == 3 || mongoose.connection.readyState == 0) {
    console.log("Connection Ready State: ", mongoose.connection.readyState)
    console.log("Attempting to connect to database")
    await mongoose.connect(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    }).then((res) => {
      console.log("Connected to MongoDB");
    }).catch((err) => {
      console.log("Mongoose Error: " + err);
    });
    User = mongoose.models.User || mongoose.model("User", userSchema)
    Token = mongoose.models.Token || mongoose.model("Token", tokenSchema)
    GptHistory = mongoose.models.GptHistory || mongoose.model("GptHistory", gptHistorySchema)
    ResetToken = mongoose.models.ResetToken || mongoose.model("ResetToken", resetTokenSchema)
  } else {
    User = mongoose.models.User || mongoose.model("User", userSchema)
    Token = mongoose.models.Token || mongoose.model("Token", tokenSchema)
    GptHistory = mongoose.models.GptHistory || mongoose.model("GptHistory", gptHistorySchema)
    ResetToken = mongoose.models.ResetToken || mongoose.model("ResetToken", resetTokenSchema)
  }
}

export async function changePasswordOf(_id, password) {
  let { salt, key } = await encryptPassword(password)
  let updated = User.findOneAndUpdate({_id}, {
    salt,
    key,
  }, {
    new: true
  })
  return updated
}

export async function getUserAiSession(user_id) {
  let openSession = (await User.findOne({user_id})).openAiSession
  if(!openSession || !(typeof openSession === "boolean")) {
    await setAiSession(user_id, false)
    return false
  }
  return openSession
}

export async function setAiSession(user_id, status) {
  console.log("OpenAi Session? " + status)
  let updated = await User.findOneAndUpdate({user_id}, {
    $set: {
      openAiSession: status
    }
  }, {
    new: true
  })
  return updated
}
export async function getGptHistory(_id) {
  let gptHistory = await GptHistory.findOne({user_id: _id})
  return gptHistory
}

export async function deleteGptHistory(_id) {
  await GptHistory.deleteOne({user_id: _id})
}

export async function createGptHistory(user_id, name, content) {
  let currentSections = [{
    name: name ?? "Default",
    content: content ?? []
  }]
  let gptHistory = await GptHistory({
    user_id: user_id,
    sections: currentSections
  })
  await gptHistory.save()
}

export async function addToGptHistorySection(user_id, section, name = null, content) {
  let found = await GptHistory.findOne({user_id})
  console.log(found)
  if(!found) {
    console.log("Making new one")
    createGptHistory(user_id, name, content)
  } else {
    let currentSections = found.sections ? found.sections : [{
      name: "Default"
    }]
    currentSections[section].name = name ? name : currentSections[section].name
    currentSections[section].content = content
    let updated = await GptHistory.findOneAndUpdate({user_id}, {
      $set: {
        sections: currentSections
      }
    }, {
      new: true
    })
  }
}

export async function makeTokenFor(user_id) {
  await Token.deleteMany({user_id: user_id})
  let generatedToken = generateRandomToken()
  console.log(`Token: ${generatedToken}`)
  let newToken = await new Token({
    user_id,
    token: generatedToken
  })
  let saved = await newToken.save()
  return {success: true, token: saved}
}

export async function makeResetTokenFor(user_id) {
  await ResetToken.deleteMany({user_id: user_id})
  let generatedToken = generateRandomToken()
  console.log(`Reset Token: ${generatedToken}`)
  let newToken = await new ResetToken({
    user_id,
    token: generatedToken
  })
  let saved = await newToken.save()
  return {success: true, token: saved}
}

export async function findResetToken(token) {
  let dbToken = await ResetToken.findOne({token})
  return dbToken
}

export async function deleteResetTokenFor(user_id) {
  try {
    await ResetToken.deleteOne({user_id: user_id})
    return {success: true}
  } catch (error) {
    return {success: false, error: error}
  }
}

export async function findToken(token) {
  let dbToken = await Token.findOne({token})
  return dbToken
}

export async function deleteTokenFor(user_id) {
  try {
    await Token.deleteOne({user_id: user_id})
    return {success: true}
  } catch (error) {
    return {success: false, error: error}
  }
}

export async function createUser(user) {
  if(!user.password || !user.email || !user.username) {
    console.log("Missing required fields")
    return {success: false, error: "MIssing required fields"}
  }
  let { salt, key } = await encryptPassword(user.password)
  let user_id = generateRandomId()
  console.log(`Id: ${user_id}`)
  console.log(`Salt: ${salt}\nKey: ${key}`)
  let checkingForUser = await User.findOne(
    {
      $or: [
        {username: user.username},
        {email: user.email}
      ]
    }
    )
  if(user.password.length < 6) {
    console.log("Password is less than 6 characters")
    return {success: false, error: "Password must be more than 6 characters"}
  }
  if(checkingForUser) {
    console.log("User already exists")
    return {success: false, error: "User already exists"}
  } 
  user.user_id = user_id
  user.key = key
  user.salt = salt
  let newUser = User(user);
  const saved = await newUser.save()
  console.log("New User: ", saved)
  return {success: true, user: saved};
}

export async function updateTodos(user_id, todos) {
  let updated = await User.findOneAndUpdate({user_id}, {
    $set: {
      todos
    }
  }, {
    new: true
  })
  console.log("Updated: ", updated)
  if(!updated) {
    console.log("All is well")
    return { success: false, todos, error: "Couldn't add new todo"}
  }
  return {success: true, todos, user: updated}
}


export async function checkForUser(usernameOrEmail, _id) {
  let user = await User.findOne({
    $or: [
      {username: usernameOrEmail},
      {email: usernameOrEmail},
      {_id: _id}
    ]
  })
  // console.log("User that we found: ", user)
  return user
}

export async function checkForGoogleUser(googleSub) {
  console.log("Sub: ", googleSub)
  let user = await User.findOne({googleSub})
  // console.log("User that we found: ", user)
  return user
}

export async function loginUser(usernameOrEmail, password) {
  let user = await User.findOne({
    $or: [
      {username: usernameOrEmail},
      {email: usernameOrEmail}
    ]
  })
  if(user) {
    let salt = user.salt
    let { keyString} = await deriveKeyFromPassword(password, convertHexToBuffer(salt))
    console.log(`User Key: ${user.key} and or generated key: ${keyString}`)
    if(user.key == keyString) return { success: true, user: user}
    return { success: false, error: "Incorrect password" }
  } else {
    return { success: false, error: "User with that username or email doesn't exist" }
  }
}

export async function updateUserGoogleSub(user_id, googleSub) {
  let updated = await User.findOneAndUpdate({user_id}, {
    $set: {
      googleSub
    }
  }, {
    new: true
  })
  return updated
}

export async function updateUserDay(user_id, currentDay = null) {
  let updated = await User.findOneAndUpdate({user_id}, {
    $set: {
      currentDay
    }
  }, {
    new: true
  })
  return updated
}

export async function updateUserVerification(user_id, verified = null) {
  let updated = await User.findOneAndUpdate({user_id}, {
    $set: {
      verified
    }
  }, {
    new: true
  })
  return updated
}

export async function updateDemographics({
  user_id = null,
  age = null,
  country = null,
  region = null,
  incomeBracket = null,
  raceEthnicity = null,
  personalRaceDefiniton = null,
  education = null,
  personalEducationDefinition = null,
  pregnancyStatus = null,
  trimester = null,
  daysIntoTrimester = null,
  deliveryDate = null
}) {
  let found = await User.findOne({user_id})
  console.log("Found: ", found)
  console.log({
    age, country, region, incomeBracket, raceEthnicity, personalRaceDefiniton, personalEducationDefinition, pregnancyStatus, trimester, daysIntoTrimester, deliveryDate
  })
  let updated = await User.findOneAndUpdate({user_id}, {
    $set: {
      age: age ?? found.age,
      country: country ?? found.country,
      region: region ?? found.region,
      incomeBracket: incomeBracket ?? found.incomeBracket,
      raceEthnicity: raceEthnicity ?? found.raceEthnicity,
      personalRaceDefiniton: personalRaceDefiniton ?? found.personalRaceDefinition,
      education: education ?? found.education,
      personalEducationDefinition: personalEducationDefinition ?? found.personalEducationDefinition,
      pregnancyStatus: pregnancyStatus ?? found.pregnancyStatus,
      trimester: trimester ?? found.trimester,
      daysIntoTrimester: daysIntoTrimester ?? found.daysIntoTrimester,
      deliveryDate: deliveryDate ?? found.deliveryDate
    }
  }, {
    new: true
  })
  return updated
}
