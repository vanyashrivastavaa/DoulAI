export default function obtainSessionUser(obj) {
    //Stripping object of sensitive data
    obj.salt = null
    obj.key = null
    return obj
}